from collections import Counter
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread, Lock
from time import sleep, monotonic
from urllib.parse import urlsplit
import gzip
import json
import sys

class Ledger:
    def __init__(self):
        self.lock = Lock()
        self.events = Counter()
        self.sizes = Counter()
        self.accepted = Counter()
        self.http_totals = Counter()
        self.usage_samples=[]
        self.posts = self.wire_bytes = self.ndjson_bytes = 0
        self.traffic = []
    def record(self, path, method, status, raw, encoding, response, response_encoding, t):
        if not path.rstrip('/').endswith('/_bulk'):
            return
        body = gzip.decompress(raw) if 'gzip' in encoding.lower() else raw
        lines = [ln for ln in body.splitlines() if ln.strip()]
        if len(lines) % 2:
            raise ValueError('Unexpected Elasticsearch bulk action/document pairs')
        reply = gzip.decompress(response) if 'gzip' in response_encoding.lower() else response
        items = json.loads(reply).get('items', []) if status < 300 else []
        with self.lock:
            self.posts += 1
            self.wire_bytes += len(raw)
            self.ndjson_bytes += len(body)
            for i in range(0, len(lines), 2):
                row = json.loads(lines[i + 1])
                fields = row.get('fields', {})
                name = fields.get('QaasEvent') or '(diagnostic)'
                self.events[name] += 1
                self.sizes[name] += len(lines[i + 1])
                if items:
                    result = next(iter(items[i // 2].values()))
                    self.accepted[name] += int(200 <= result['status'] < 300)
                    if 200 <= result['status'] < 300 and name!='(diagnostic)' and len(self.usage_samples)<30:
                        safe={'QaasEvent','Team','TeamKnown','System','SystemKnown','Project','ProjectKnown','Version','QaasVersion','Environment','AttemptId','ExecutionId','ExecutionType','Outcome','Mode','Features','Failed','DurationMs','TestsExecuted','AssertionsExecuted','AssertionsFailed','AssertionsPassed','Requests','Misses','HandlerErrors','Http5xx','ServerId','BatchSequence','Port'}
                        self.usage_samples.append({k:v for k,v in fields.items() if k in safe})
                    if 200 <= result['status'] < 300 and name=='MockerHttpRequests':
                        for key in ('Requests','HandlerErrors','Misses','Http5xx'):
                            self.http_totals[key]+=int(fields.get(key,0))
            self.traffic.append({'t':t,'ack':monotonic(),'status':status, 'wire_bytes':len(raw),'documents':len(lines)//2,'errors':any('error' in list(item.values())[0] for item in items)})
    def snapshot(self):
        with self.lock:
            return {'posts':self.posts,'wire_body_bytes':self.wire_bytes, 'ndjson_bytes':self.ndjson_bytes, 'emitted':dict(self.events),'accepted':dict(self.accepted),'document_bytes':dict(self.sizes),
                    'usage_samples':list(self.usage_samples),'http_totals':dict(self.http_totals),'timeline':list(self.traffic)}

class AuditProxy(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*_): pass
    def body(self):
        if self.headers.get('Transfer-Encoding','').lower() != 'chunked':
            return self.rfile.read(int(self.headers.get('Content-Length','0')))
        chunks = bytearray()
        while True:
            size = int(self.rfile.readline(128).split(b';')[0],16)
            if not size:
                while self.rfile.readline(1024).strip(): pass
                return bytes(chunks)
            chunks.extend(self.rfile.read(size))
            assert self.rfile.read(2)==b'\r\n'
    def forward(self):
        upstream=HTTPConnection('127.0.0.1',19278,timeout=20)
        content=self.body()
        hop={'host','connection','keep-alive','transfer-encoding','content-length','proxy-connection','upgrade','trailer','te'}
        request_type=self.headers.get('Content-Encoding','')
        headers={k:v for k,v in self.headers.items() if k.lower() not in hop}
        path=urlsplit(self.path).path
        started=monotonic()
        try:
            if path.rstrip('/').endswith('/_bulk') and self.server.delay:
                sleep(self.server.delay)
            upstream.request(self.command,self.path,body=content or None,headers=headers)
            resp=upstream.getresponse();reply=resp.read()
            self.server.ledger.record(path,self.command,resp.status,content,request_type,reply,resp.getheader('Content-Encoding',''),started)
            try:
                self.send_response(resp.status)
                for k,v in resp.getheaders():
                    if k.lower() not in hop:self.send_header(k,v)
                self.send_header('Content-Length',str(len(reply)));self.end_headers()
                if self.command!='HEAD':self.wfile.write(reply)
            except (ConnectionResetError,BrokenPipeError,ConnectionAbortedError): pass
        finally:
            upstream.close()
    do_GET=do_POST=do_PUT=do_HEAD=do_DELETE=forward

class Relay(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,port,delay):
        super().__init__(('127.0.0.1',port),AuditProxy)
        self.delay=delay
        self.ledger=Ledger()
        self.thread=Thread(target=self.serve_forever,kwargs={'poll_interval':.05},daemon=True)
    def handle_error(self, request, client_address):
        if isinstance(sys.exception(),(ConnectionResetError,BrokenPipeError,ConnectionAbortedError)): return
        super().handle_error(request,client_address)
    def __enter__(self):self.thread.start();return self
    def __exit__(self,*_):
        self.shutdown();self.server_close();self.thread.join(2)
    @property
    def url(self):return 'http://127.0.0.1:'+str(self.server_port)
