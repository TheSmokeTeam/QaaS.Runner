import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
F="event."
dims=["Team","Project","System","Environment","ExecutionType","Version","Features"]
time_range="[${__from} TO ${__to}]"

def metric(kind, field=None, id="1", **settings):
    m={"id":id,"type":kind}
    if field:m["field"]=F+field
    if settings:m["settings"]=settings
    return m
def terms(field,id="2",limit=20,sort="_count"):
    return {"id":id,"type":"terms","field":F+field,"settings":{"size":str(limit),"order":"desc","orderBy":sort,"min_doc_count":"1"}}
def hist(field,id="2"):
    return {"id":id,"type":"date_histogram","field":F+field,"settings":{"interval":"auto","min_doc_count":"1"}}
def ratio(script, names, id="5"):
    return {"id":id,"type":"bucket_script","settings":{"script":script},"pipelineVariables":[{"name":k,"pipelineAgg":v} for k,v in names.items()]}

def dashboard(product):
    prefix=product.lower()
    ds={"type":"elasticsearch","uid":"qaas-"+prefix+"-usage-v1"}
    base="event.Conflict:false AND "+" AND ".join("event."+d+":${"+d+":lucene}" for d in dims)
    start="event.Kind:Execution AND event.StartedAt:"+time_range
    end="event.Kind:Execution AND event.FinishedAt:"+time_range
    http="event.Kind:HTTP AND event.BatchAt:"+time_range
    panels=[]
    def panel(title,desc,kind,xy,query,metrics,buckets=None,unit="short",alias=None,select=None,renames=None,all_targets=None):
        x,y,w,h=xy
        target={"datasource":ds,"refId":"A","query":base+" AND "+query,"metrics":metrics,"bucketAggs":buckets if buckets is not None else [terms("Kind",limit=1)]}
        if alias:target["alias"]=alias
        po={"id":len(panels)+1,"type":kind,"title":title,"description":desc,"gridPos":{"x":x,"y":y,"w":w,"h":h},
            "datasource":ds,"targets":all_targets or [target],"fieldConfig":{"defaults":{"unit":unit,"noValue":"—"},"overrides":[]}}
        if kind=="stat":
            po["options"]={"textMode":"value","graphMode":"none","colorMode":"none","reduceOptions":{"values":False,"calcs":["lastNotNull"],"fields":select or ""}}
        elif kind=="timeseries":
            po["options"]={"legend":{"showLegend":True,"placement":"bottom","displayMode":"list"},"tooltip":{"mode":"multi","sort":"desc"}}
            po["fieldConfig"]["defaults"]["min"]=0
            po["fieldConfig"]["defaults"]["custom"]={"drawStyle":"bars","barAlignment":0,"lineWidth":1,"fillOpacity":55,"showPoints":"never","spanNulls":False}
        else:
            po["options"]={"showHeader":True,"cellHeight":"sm","footer":{"show":False}}
        if renames:po["transformations"]=[{"id":"organize","options":{"renameByName":renames}}]
        panels.append(po)
        return po
    def pick_metric(script,name,params,id):
        # Script-only cardinality can emit an empty list for a nonmember. With field+script ES counts that as a value.
        return metric("cardinality",id=id,precision_threshold=4000,script={"source":script,"params":dict(params,axis=F+name)})
    def row(title,y):
        panels.append({"id":len(panels)+1,"type":"row","title":title,"collapsed":False,"gridPos":{"x":0,"y":y,"w":24,"h":1},"panels":[]})
    row("Execution health",0)
    for i,(title,query,met,unit,desc) in enumerate([
        ("Runs started",start,metric("count"),"short","One observed start per distinct execution attempt in the selected interval."),
        ("Runs completed",end,metric("count"),"short","Distinct observed terminal attempts, successful, cancelled or failed. Finish time determines inclusion."),
        ("Unsuccessful finishes",end,metric("avg","Failed"),"percentunit","Sum of non-success flags divided by observed finishes. A missing finish never enters either side. Cancellation is a separate outcome below."),
        ("P95 run duration",end,metric("percentiles","DurationMs",percents=["95"]),"ms","95th percentile of individual monotonic durations in milliseconds, over observed finishes. Executions without a measured duration contribute no sample.")
    ]): panel(title,desc,"stat",(i*6,1,6,4),query,[met],unit=unit)
    panel("Starts by environment","Execution starts per time bucket by the framework's CI/local classification. A gap indicates no observed starts.",
          "timeseries",(0,5,12,8),start,[metric("count")],[terms("Environment"),hist("StartedAt","3")],alias="{{term event.Environment}}")
    panel("Finished outcomes","Terminal attempts per time bucket by outcome. Compare cancellation, execution errors and test failures to successful finishes.",
          "timeseries",(12,5,12,8),end,[metric("count")],[terms("Outcome"),hist("FinishedAt","3")],alias="{{term event.Outcome}}")
    panel("No observed finish after 15 min","Starts in this range at least 15 minutes before its end, with no terminal by that cutoff. Includes long-running services and lost records. A dash means there are no matching records.",
          "stat",(0,13,6,4),start+' AND event.StartedAt:[* TO "${__to:date:iso}||-15m"] AND ((*:* AND NOT _exists_:event.FinishedAt) OR event.FinishedAt:{${__to} TO *])',[metric("count")])
    panel("Finish without observed start","Terminal attempts in range for which no start exists in the retained reconciliation data. A dash means no matches.",
          "stat",(6,13,6,4),end+" AND NOT _exists_:event.StartedAt",[metric("count")])
    frac=ratio("params.n / ((${__to}L - ${__from}L) / 1000.0)",{"n":"1"})
    panel("Completed runs / s","Distinct finishes divided by the selected interval in seconds. The dashboard uses the whole chosen interval, including its quiet periods.",
          "stat",(12,13,6,4),end,[metric("count"),frac],unit="ops",select="/^Bucket Script$/")
    panel("Unknown attribution","Starts missing at least one trusted team, project or system. Choose (unattributed) in an owner filter to see these attempts. A dash means no matches.",
          "stat",(18,13,6,4),start+" AND (event.TeamKnown:false OR event.ProjectKnown:false OR event.SystemKnown:false)",[metric("count")])
    for pp,(x,w) in zip(panels[-4:],[(0,5),(5,5),(10,5),(15,5)]):
        pp["gridPos"].update(x=x,w=w)
    cq=panel("Conflicting replays","Distinct reconciliation keys with incompatible copies of one phase or HTTP summary. Conflicting keys are excluded from all other panels; inspect the original logs by attempt or server identity.",
             "stat",(20,13,4,4),"event.Conflict:true",[metric("count")],[terms("Conflict",limit=1)])
    cq["targets"][0]["query"]=cq["targets"][0]["query"].replace("event.Conflict:false AND ","",1)
    row("Observed and returning owners",17)
    for i,axis in enumerate(["Team","Project","System"]):
        q=start+" AND event."+axis+"Known:true"
        panel("Active "+axis.lower()+"s","Estimated distinct known "+axis.lower()+" labels with an observed start in the selected range. This measures usage. No eligible-owner denominator is supplied.",
              "stat",(i*8,18,8,3),q,[metric("cardinality",axis,precision_threshold=4000)])
        compare="long a=Long.parseLong(params.lo); long b=Long.parseLong(params.hi); long mid=a+(b-a)/2; return doc['event.StartedAt'].value.toInstant().toEpochMilli() "
        par={"lo":"${__from}","hi":"${__to}"}
        left=pick_metric(compare+"< mid ? [doc[params.axis].value] : []; ",axis,par,"1")
        right=pick_metric(compare+">= mid ? [doc[params.axis].value] : []; ",axis,par,"3")
        union=metric("cardinality",axis,"4",precision_threshold=4000)
        both=ratio("params.a == 0 || params.b == 0 ? Double.NaN : Math.max(0,Math.min(Math.min(params.a,params.b),params.a+params.b-params.u))",{"a":"1","b":"3","u":"4"})
        panel("Returning "+axis.lower()+"s","Estimated distinct known "+axis.lower()+" labels present in both equal-duration halves of the selected UTC range. Intersection = first + second − union, bounded by the smaller half. If either half has no observed owners, comparison is unavailable.",
              "stat",(i*8,21,8,3),q,[left,right,union,both],select="/^Bucket Script$/")
    panel("Usage by team, project and system","Observed starts by trusted ownership. Shows the five busiest teams, their five busiest projects and five systems each. Names need not be unique across owners.",
          "table",(0,24,12,8),start,[metric("count")],[terms("Team",limit=5),terms("Project","3",5),terms("System","4",5)],
          renames={"event.Team":"Team","event.Project":"Project","event.System":"System","Count":"Starts"})
    panel("Usage by version and mode","Observed starts for the eight most active versions and their execution modes. Use the filters to compare a specific release or environment.",
          "table",(12,24,12,8),start,[metric("count")],[terms("Version",limit=8),terms("ExecutionType","3",8)],renames={"event.Version":"Version","event.ExecutionType":"Mode","Count":"Starts"})
    panel("Feature use","Observed starts by configured, allowlisted capability per time bucket. One attempt can use several features, so series are not additive.",
          "timeseries",(0,32,12,8),start,[metric("count")],[terms("Features"),hist("StartedAt","3")],alias="{{term event.Features}}")
    outcome=panel("Outcomes by team and system","Observed finishes and non-success counts per owner. The last column is the non-success fraction, including cancellations. Shows the eight teams and eight systems per team with the most finishes.",
          "table",(12,32,12,8),end,[metric("count"),metric("sum","Failed","4"),metric("avg","Failed","5")],[terms("Team",limit=8),terms("System","3",8)],
          renames={"event.Team":"Team","event.System":"System","Count":"Finishes","Sum":"Unsuccessful","Average":"Failure rate","Sum event.Failed":"Unsuccessful","Average event.Failed":"Failure rate"})
    outcome["fieldConfig"]["overrides"]=[{"matcher":{"id":"byName","options":"Failure rate"},"properties":[{"id":"unit","value":"percentunit"}]}]
    if product=="Runner":
        row("Test execution",40)
        for i,(title,field,desc) in enumerate([("Test plans executed","TestsExecuted","Full run test-plan/case units. Act and assert phases do not count again."),
                                             ("Assertions executed","AssertionsExecuted","Observed completed assertion results. Interrupted attempts without a reliable result count are excluded.")]):
            panel(title,desc+" Grouped by terminal time; a missing value is not a zero.","stat",(6*i,41,6,4),end+" AND _exists_:event."+field,[metric("sum",field)])
        panel("Assertions / s","Sum of known completed assertion counts divided by the selected range in seconds. Counts are attributed to finish time.",
              "stat",(12,41,6,4),end+" AND _exists_:event.AssertionsExecuted",[metric("sum","AssertionsExecuted"),frac],unit="ops",select="/^Bucket Script$/")
        panel("Unmeasured assertion counts","Finishes without an exact completed assertion count. They do not enter assertion totals or throughput.",
              "stat",(18,41,6,4),end+" AND NOT _exists_:event.AssertionsExecuted",[metric("count")])
        detail=panel("Mode, case and batch","Finishes by run/act/assert, named-case expansion and command-batch membership. An attempt may belong to both a case and a batch.",
            "table",(0,45,24,8),end,[metric("count"),metric("sum","TestsExecuted","6"),dict(metric("sum","AssertionsExecuted","7"),hide=True),dict(metric("avg","AssertionsExecuted","8"),hide=True),ratio("params.mean >= 0 ? params.total : Double.NaN",{"mean":"8","total":"7"},"9")],
            [terms("ExecutionType"),terms("Invocation","3")],
            renames={"event.ExecutionType":"Mode","event.Invocation":"Invocation","Count":"Finishes","Sum event.TestsExecuted":"Test plans","Bucket Script":"Assertions"})
        detail["transformations"][0]["options"]["excludeByName"]={"Sum event.AssertionsExecuted":True,"Average":True,"Average event.AssertionsExecuted":True}
    else:
        row("HTTP traffic and failures",40)
        for i,(title,field,desc) in enumerate([("Completed requests","Requests","Sum of completed requests from nonempty server batches."),
                                                ("Handler error rate","HandlerErrors","Processing or response errors, including errors recovered by a fallback."),
                                                ("Route miss rate","Misses","Route/method misses successfully handled by the not-found fallback."),
                                                ("HTTP 5xx rate","Http5xx","Responses with status 500–599, including deliberate mocks.")]):
            mets=[metric("sum",field)]
            if i:mets.extend([metric("sum","Requests","3"),ratio("params.n / params.total",{"n":"1","total":"3"})])
            panel(title,desc+(" Divided by total completed requests, weighted across batches." if i else "")+" Time is batch publication time.",
                  "stat",(6*i,41,6,4),http,mets,unit="percentunit" if i else "short",select="/^Bucket Script$/" if i else None)
        rate_panel=panel("HTTP requests / s","Sum of observed request deltas divided by seconds in each UTC histogram bucket. Buckets are at least ten seconds wide to match the reporting period. Counts are attributed to flush time. Empty windows have no observation.",
              "timeseries",(0,45,12,8),http,[metric("rate","Requests",unit="second",mode="sum")],[hist("BatchAt")],unit="reqps",alias="Requests / s")
        rate_panel["interval"]="10s"
        for_outcomes=[]
        for i,(f,label) in enumerate([("HandlerErrors","Handler errors"),("Misses","Route misses"),("Http5xx","HTTP 5xx")]):
            for_outcomes.append({"refId":chr(65+i),"datasource":ds,"query":base+" AND "+http,"metrics":[metric("sum",f)],"bucketAggs":[hist("BatchAt")],"alias":label})
        timeline=panel("HTTP outcomes over time","Counts per flush-time bucket of at least ten seconds. A handler error may also return 5xx. These series must not be added together.",
              "timeseries",(12,45,12,8),http,[],all_targets=for_outcomes)
        timeline["interval"]="10s"
        servers=panel("Busiest HTTP server instances","Top 20 server lifetimes by summed requests. Server ID is a drill-down identifier, port is contextual. Distinct handler errors, misses and HTTP 5xx can overlap.",
              "table",(0,53,24,8),http,[metric("sum","Requests","1"),metric("sum","HandlerErrors","4"),metric("sum","Misses","5"),metric("sum","Http5xx","6")],
              [terms("ServerId",limit=20,sort="1"),terms("Port","3",1)],
              renames={"event.ServerId":"Server instance","event.Port":"Port","Sum event.Requests":"Requests","Sum event.HandlerErrors":"Handler errors","Sum event.Misses":"Route misses","Sum event.Http5xx":"HTTP 5xx"})
        servers["fieldConfig"]["overrides"]=[{"matcher":{"id":"byName","options":"Port"},"properties":[{"id":"unit","value":"none"},{"id":"decimals","value":0}]}]
    p=panel("Recent unsuccessful executions","Up to 25 failed or cancelled terminal attempts in descending event time. The attempt ID identifies the matching lifecycle pair in Elasticsearch. Existing application diagnostics retain their usual scope.",
            "table",(0,53 if product=="Runner" else 61,24,7),end+" AND event.Failed:1",[metric("raw_data",size="25")],[])
    visible=["event.FinishedAt","event.Team","event.Project","event.System","event.ExecutionType","event.Outcome","event.DurationMs","event.AttemptId"]
    p["transformations"]=[{"id":"filterFieldsByName","options":{"include":{"names":visible}}},
                           {"id":"organize","options":{"indexByName":{f:i for i,f in enumerate(visible)},"renameByName":{f:f.split(".")[1] for f in visible}}}]
    p["fieldConfig"]["overrides"]=[{"matcher":{"id":"byName","options":"FinishedAt"},"properties":[{"id":"unit","value":"dateTimeAsIso"}]},
                                    {"matcher":{"id":"byName","options":"DurationMs"},"properties":[{"id":"unit","value":"ms"}]}]
    variables=[]
    for i,d in enumerate(dims):
        prev=" AND ".join("event."+n+":${"+n+":lucene}" for n in dims[:i])
        variables.append({"name":d,"label":{"ExecutionType":"Mode","Features":"Feature"}.get(d,d),"type":"query","datasource":ds,
            "query":json.dumps({"find":"terms","field":F+d,"query":"event.Conflict:false"+(" AND "+prev if prev else ""),"size":1000}),"refresh":2,"sort":1,
            "multi":True,"includeAll":True,"allValue":"*","options":[],"current":{"selected":True,"text":["All"],"value":["$__all"]}})
    return {"uid":"qaas-"+prefix+"-usage","title":"QaaS "+product+" observability","description":"Usage and reliability from reconciled Elasticsearch logs.","schemaVersion":40,
            "version":2,"tags":["qaas",prefix],"timezone":"utc","editable":True,"time":{"from":"now-14d","to":"now"},"refresh":"1m","templating":{"list":variables},"panels":panels}
if __name__=="__main__":
    for product in ["Runner","Mocker"]:
        out=ROOT/product/"grafana";out.mkdir(exist_ok=True)
        (out/(product.lower()+"-usage.json")).write_text(json.dumps(dashboard(product),indent=2)+"\n",encoding="utf-8")
