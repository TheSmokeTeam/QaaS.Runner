"""Actual Runner HTTP transactions against Mocker, plus distinct 5xx/miss outcomes."""
from pathlib import Path
import json, os, subprocess, time, signal, sys
import requests
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'evidence/mocker/revision-bench'))
from relay import Relay
out=root/'lab/results/cross';out.mkdir(exist_ok=True)
m=root/'mocker/QaaS.Mocker.Example/bin/Release/net10.0/QaaS.Mocker.Example.dll'
r=root/'runner/QaaS.Runner.E2ETests/bin/Release/net10.0/QaaS.Runner.E2ETests.dll'
mbase=(root/'evidence/mocker/dashboard-validation/mocker.yaml').read_text().replace('IsLocalhost: false','IsLocalhost: true')
rb=(root/'runner/QaaS.Runner.Tests/TestData/http-get-empty-request.qaas.yaml').read_text()
assertion='\nAssertions:\n  - Name: ObservedSuccess\n    Assertion: RabbitExhaustiveCombinationsAssertion\n    SessionNames: [empty-http-get]\n'
outcomes={}
for mode,port in [('false',19160),('true',19161)]:
 name='ReviewLab'+mode
 cof=out/('mocker-'+mode+'.yaml');rof=out/('runner-'+mode+'.yaml')
 cof.write_text(mbase.replace('Team: Checkout',f'Team: {name}').replace('Port: 18145',f'Port: {port}'))
 rof.write_text(rb.replace('Team: investigation',f'Team: {name}').replace('Port: 1',f'Port: {port}').replace('Route: /','Route: /ok').replace('TimeoutMs: 100','TimeoutMs: 5000')+assertion)
 env=os.environ.copy();env['QAAS_USAGE_ENABLED']=mode
 with Relay(0,0) as es, (out/('mocker-'+mode+'.log')).open('wb') as logs:
  args=['--no-env','--send-logs','--elastic-uri',es.url]
  host=subprocess.Popen(['dotnet',str(m),'run',str(cof),*args],cwd=out,env=env,stdout=logs,stderr=logs)
  observed=[]
  try:
   cutoff=time.monotonic()+25
   while time.monotonic()<cutoff:
    if b'Application started' in Path(logs.name).read_bytes():break
    if host.poll() is not None:raise RuntimeError((host.returncode,Path(logs.name).read_text()[-2000:]))
    time.sleep(.05)
   else:raise RuntimeError('missing host readiness')
   rr=subprocess.run(['dotnet',str(r),'run',str(rof),*args],cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
   (out/('runner-'+mode+'.log')).write_bytes(rr.stdout)
   assert rr.returncode==0,rr.stdout[-2500:]
   for path,status in [('/ok',200),('/degraded',503),('/missing',404),('/throw',500)]:
    resp=requests.get(f'http://127.0.0.1:{port}'+path,timeout=5)
    assert resp.status_code==status,(path,status,resp.status_code)
    observed.append([path,status,resp.text])
  finally:
   host.send_signal(signal.SIGTERM)
   try:host.wait(timeout=15)
   except subprocess.TimeoutExpired:host.kill();host.wait();raise
  time.sleep(.3)
  receipt=es.ledger.snapshot()
  expected={'Requests':5,'HandlerErrors':1,'Misses':1,'Http5xx':2} if mode=='true' else {}
  assert receipt['http_totals']==expected,(receipt['http_totals'],expected)
  for prod in ('Runner','Mocker'):
   for phase in ('Started','Finished'):
    assert receipt['accepted'].get(prod+'Execution'+phase,0)==int(mode=='true'),receipt['accepted']
  assert host.returncode==0,host.returncode
  outcomes[mode]={'http':observed,'runner_exit':rr.returncode,'mocker_exit':host.returncode,'receipt':receipt}
assert outcomes['false']['http']==outcomes['true']['http']
(out/'cross-result.json').write_text(json.dumps(outcomes,indent=2))
print('PASS Runner -> Mocker: both exits and all HTTP status/bodies unchanged; opt-in receipt contains 5 requests, 1 miss, 1 handler error, 2 HTTP 5xx',flush=True)
