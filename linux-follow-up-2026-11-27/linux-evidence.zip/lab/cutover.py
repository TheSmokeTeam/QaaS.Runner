"""Isolated exact-asset check for the two pinned operator attachments."""
import datetime as dt
import json, re, time, pathlib, sys
import requests

root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'evidence/runner/revision-verification'))
from check_charts import api, panel_frames, provision
from oracle import oracle

es='http://127.0.0.1:19278'
def req(method,path,body=None,data=None):
    r=requests.request(method,es+path,json=body,data=data,headers={'Content-Type':'application/x-ndjson'} if data else {},timeout=20)
    if not r.ok: raise RuntimeError((method,path,r.status_code,r.text))
    return r.json()

def read_console(p):
    src=(root/'lab/assets'/f'{p}.console').read_text()
    src=re.sub(r'"""\s*\n(.*?)\n\s*"""',lambda m:json.dumps(m[1]),src,flags=re.S)
    parts=re.split(r'^(PUT|POST)\s+(/\S+)\s*$',src,flags=re.M)
    out=[]
    for verb,path,body in zip(parts[1::3],parts[2::3],parts[3::3]):
        body=re.sub(r'^\s*#.*$','',body,flags=re.M).strip()
        out.append((verb,path,json.loads(body) if body else None))
    return out

r,m=map(read_console,('runner','mocker'))
assert r[:2]==m[:2]
pipe='qaas-usage-stamp-v1'
a,b='qaas-2026.11.26','qaas-2026.11.27'
req('PUT','/_ingest/pipeline/lab-original',{'processors':[{'set':{'field':'lab_marker','value':'kept'}}]})
req('PUT','/'+a,{'settings':{'index.final_pipeline':'lab-original'}})
for verb,payload,body in r[:2]: req(verb,payload,body)
req('PUT','/_ingest/pipeline/lab-original',{'processors':[{'set':{'field':'lab_marker','value':'kept'}},{'pipeline':{'name':pipe}}]})
req('PUT','/'+a+'/_mapping',r[1][2]['template']['mappings'])
req('PUT','/_index_template/lab-daily',{'index_patterns':['qaas-20*'],'priority':200,'composed_of':['qaas-usage-fields-v1'],'template':{'settings':{'index.final_pipeline':'lab-original'}}})
sim=req('POST','/_index_template/_simulate_index/'+b)
assert sim['template']['settings']['index']['final_pipeline']=='lab-original'
req('PUT','/'+b)
for verb,path,body in r[2:]+m[2:]: req(verb,path,body)

start=dt.datetime(2026,11,26,23,59,55,tzinfo=dt.timezone.utc)
finish=start+dt.timedelta(seconds=10)
def iso(t):return t.isoformat().replace('+00:00','Z')
def ms(t):return int(t.timestamp()*1000)
events=[]
batch=[]
def add(i,key,ts,fields):
    row={'@timestamp':iso(ts),'fields':fields}
    batch.extend([{'index':{'_index':i,'_id':key}},row])
    if 'QaasEvent' in fields:events.append(row)
for i,ts in ((a,start),(b,finish)):
    add(i,'ordinary',ts,{'Message':'ordinary-test-marker'})
for product in ('Runner','Mocker'):
    attr={'AttemptId':product+'-cutover','Team':'Lab Team','Project':'Cutover','System':'Test','TeamKnown':True,'ProjectKnown':True,'SystemKnown':True,'ExecutionType':'Run','Version':'lab','Environment':'CI','Features':['http'] if product=='Mocker' else ['Assertions']}
    if product=='Runner':attr.update(IsBatch=False,IsCase=False)
    add(a,product+'-start',start,dict(attr,QaasEvent=product+'ExecutionStarted'))
    end=dict(attr,QaasEvent=product+'ExecutionFinished',Outcome='success',Failed=0,DurationMs=10000)
    if product=='Runner':end.update(TestsExecuted=1,AssertionsExecuted=2)
    add(b,product+'-finish',finish,end)
    add(b,product+'-finish-replay',finish,end)
    if product=='Mocker':
      add(b,'http',finish,dict(attr,QaasEvent='MockerHttpRequests',Requests=3,HandlerErrors=0,Misses=0,Http5xx=1,ServerId='lab-server',BatchSequence=1,Port=18080))
result=req('POST','/_bulk?refresh=true',data=''.join(json.dumps(x)+'\n' for x in batch))
assert not result['errors'],result
for i in (a,b):
    doc=req('GET','/'+i+'/_doc/ordinary')['_source']
    assert doc['lab_marker']=='kept' and 'qaas_usage_key' not in doc and doc['fields']['Message']=='ordinary-test-marker',doc
for doc in req('GET','/qaas-20*/_search?size=30')['hits']['hits']:
    assert doc['_source']['lab_marker']=='kept'
    if doc['_id']!='ordinary':assert 'qaas_usage_key' in doc['_source'] and 'qaas_usage_ingested' in doc['_source']
limits=time.monotonic()+115
expected={'Runner':1,'Mocker':2}
while time.monotonic()<limits:
    counts={p:req('GET','/qaasusage-'+p.lower()+'-v1/_count')['count'] for p in expected}
    if counts==expected:break
    time.sleep(2)
assert counts==expected,counts
for p in expected:
    rows=req('GET','/qaasusage-'+p.lower()+'-v1/_search')['hits']['hits']
    e=next(row['_source']['event'] for row in rows if row['_source']['event']['Kind']=='Execution')
    assert e['StartedAt']==ms(start) and e['FinishedAt']==ms(finish) and not e['Conflict'],e
    assert len(provision(p)['panels'])==(30 if p=='Runner' else 32)
    assert api('GET','/api/datasources/uid/qaas-'+p.lower()+'-usage-v1/health')['status']=='OK'
    w={'start':ms(start-dt.timedelta(seconds=5)),'end':ms(finish+dt.timedelta(seconds=5))}
    for title,flt in [('all',{}),('team',{'Team':'Lab Team'}),('empty',{'Team':'not-a-team'})]:
        frames=panel_frames(p,w,flt)
        out=oracle(p,events,w,flt,frames)
        assert not out['failures'],(p,title,out)
        print(f'PASS {p} {title}: {out}',flush=True)
print('PASS exact pinned Console, daily cutover, ordinary logs, replay and Grafana')
