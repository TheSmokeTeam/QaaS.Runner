"""Destructive only to its own local processes; exact successful request/status counts."""
import hashlib,json,math,os,pathlib,signal,statistics,subprocess,sys,time,uuid
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'evidence/mocker/revision-bench'))
from relay import Relay
seq=root/'evidence/mocker/revision-bench/load.mjs'
base=root/'evidence/mocker/bench/mocker-enabled.qaas.yaml'
binary=root/'mocker/QaaS.Mocker.Example/bin/Release/net10.0/QaaS.Mocker.Example.dll'
resultfile=root/'lab/results/http-pairs.jsonl'
def run(i,on):
 team=f'http-{uuid.uuid4().hex[:12]}'
 path=root/'lab/results'/team;path.mkdir()
 port=19847+i
 fixture=path/'mocker.yaml'
 fixture.write_text(base.read_text().replace('Team: PerfLab',f'Team: {team}').replace('Port: 19847',f'Port: {port}'))
 env=os.environ.copy();env['QAAS_USAGE_ENABLED']=str(on).lower()
 with Relay(0,0) as relay, (path/'service.log').open('wb') as l:
  start=time.monotonic()
  host=subprocess.Popen(['dotnet',str(binary),'run',str(fixture),'--no-env','--send-logs','--elastic-uri',relay.url],cwd=path,env=env,stdout=l,stderr=l)
  try:
   until=time.monotonic()+25
   while time.monotonic()<until:
    if host.poll() is not None:raise RuntimeError((host.returncode,(path/'service.log').read_text()[-1500:]))
    with (path/'service.log').open('rb') as log:
     if b'Application started' in log.read():break
    time.sleep(.02)
   else:raise RuntimeError('no readiness marker')
   ctl=subprocess.Popen(['node',str(seq),json.dumps({'concurrency':16,'scenario':'hit','port':port})],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
   def send(count,duration):
    ctl.stdin.write(json.dumps({'port':port,'count':count,'duration':duration})+'\n');ctl.stdin.flush()
    return json.loads(ctl.stdout.readline())
   try:
    warm=send(5000,0)
    t0=time.monotonic();observed=send(0,32000);t1=time.monotonic()
   finally:
    ctl.stdin.close()
    try: ctl.wait(timeout=5)
    except subprocess.TimeoutExpired: ctl.kill(); ctl.wait()
  finally:
   tstop=time.monotonic();host.send_signal(signal.SIGTERM)
   try: host.wait(timeout=12)
   except subprocess.TimeoutExpired:host.kill();host.wait();raise
  stop=time.monotonic()-tstop
  time.sleep(.3)
  ledger=relay.ledger.snapshot()
 events=ledger['accepted']; expected=warm['count']+observed['count']
 assert host.returncode==0,host.returncode
 assert ledger['http_totals'].get('Requests',0)==(expected if on else 0),(expected,ledger)
 assert events.get('MockerExecutionStarted',0)==events.get('MockerExecutionFinished',0)==int(on),events
 after=[x for x in ledger['timeline'] if t0<=x['t']<=t1]
 if on: assert events.get('MockerHttpRequests',0)>=4 and len(after)>=3,events
 stats={'pair':i,'enabled':on,'startup_s':t0-start-warm['ms']/1000,'stop_s':stop,'warmup_count':warm['count'],'observed':observed,'periodic_bulk_receipts_while_measured':len(after),'ledger':ledger,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 with resultfile.open('a') as f:f.write(json.dumps(stats)+'\n')
 print(i,on,round(observed['rps']),round(observed['p95_ms'],2),events,expected,len(after),flush=True)
 return stats
resultfile.unlink(missing_ok=True)
pairs=[]
for i in (1,2,3,4):
    pair={on:run(i,on) for on in ((False,True) if i%2 else (True,False))}
    pairs.append(pair)
for key in ('rps','p95_ms'):
    diffs=[math.log(p[True]['observed'][key]/p[False]['observed'][key])*(-1 if key=='rps' else 1) for p in pairs]
    mean=statistics.mean(diffs);d=3.182*statistics.stdev(diffs)/2
    print('SUMMARY',key,[round(100*math.expm1(x),3) for x in (mean,mean-d,mean+d)],flush=True)
