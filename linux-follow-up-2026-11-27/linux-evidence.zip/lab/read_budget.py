from pathlib import Path
import collections,json,statistics
import requests
out=Path('lab/results')
read=lambda x: [json.loads(line) for line in x.read_text().splitlines()]
rows=read(out/'budget-probe.jsonl')
u='http://127.0.0.1:19278'
requests.post(u+'/qaas-20*/_refresh',timeout=10).raise_for_status()
for row in rows:
 resp=requests.post(u+'/qaas-20*/_search',json={'size':100,'query':{'term':{'fields.Team.keyword':row['owner']}}},timeout=10)
 resp.raise_for_status()
 ev=[h['_source']['fields'] for h in resp.json()['hits']['hits'] if h['_source']['fields'].get('QaasEvent')]
 ids=collections.defaultdict(set);nums=collections.Counter()
 for v in ev:
  name=v['QaasEvent'];ids[name].add(v['AttemptId']);nums[name]+=1
 start,stop='MockerExecutionStarted','MockerExecutionFinished'
 row['elasticsearch_readback']=dict(nums)
 row['complete_pair_readback']=nums[start]==nums[stop]==1 and ids[start]==ids[stop]
 print(row['configured_flush_ms'],row['receipt']['accepted'],dict(nums))
for ms in (0,32,75,125):
 units=[r for r in rows if r['configured_flush_ms']==ms]
 print('BUDGET',ms,sum(r['complete_pair_readback'] for r in units),'/',len(units),'median exit ms',round(1000*statistics.median(r['elapsed_s'] for r in units)))
(out/'budget-probe-reconciled.jsonl').write_text('\n'.join(json.dumps(x) for x in rows)+'\n')
