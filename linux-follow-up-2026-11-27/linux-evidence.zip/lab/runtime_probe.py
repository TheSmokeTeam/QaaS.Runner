"""Matched real CLI probes using native Elasticsearch, with per-item receipts and fresh IDs."""
import collections, hashlib, json, math, os, pathlib, re, statistics, subprocess, sys, threading, time, uuid
import requests
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'evidence/mocker/revision-bench'))
from relay import Relay
es='http://127.0.0.1:19278'
where=root/'lab/results'
where.mkdir(exist_ok=True)
report=where/('startup-failures.jsonl' if '--failures-only' in sys.argv else 'budget-probe.jsonl' if '--budget-only' in sys.argv else 'cli-pairs.jsonl')
fixtures=root/'evidence'
new={
'Runner':root/'runner/QaaS.Runner.E2ETests/bin/Release/net10.0/QaaS.Runner.E2ETests.dll',
'Mocker':root/'mocker/QaaS.Mocker.Example/bin/Release/net10.0/QaaS.Mocker.Example.dll'}
old={p:root/'lab/bins'/f'{p.lower()}-base'/n.name for p,n in new.items()}
def one(p,kind,q,relay,prior=False,delay=0,flush=None):
 case='run-'+uuid.uuid4().hex[:12]
 d=where/case;d.mkdir()
 binary=(old if prior else new)[p]
 if p=='Runner':
    text=(fixtures/'runner/bench/short.qaas.yaml').read_text().replace('Team: PerfLab',f'Team: {case}')
    text=text.replace('  System:', '  ExtraLabels:\n    Project: Signoff\n  System:')
    cfg=d/'short.yaml'; cfg.write_text(text)
    cf=fixtures/'runner/bench/cases'
    batch=d/'batch.yaml'
    batch.write_text(f'Commands:\n  - Id: Prepare\n    Command: act {cfg} --no-env\n  - Id: Cases\n    Command: run {cfg} --no-env --cases {cf}\n')
    args=['execute',str(batch)]
    expected=5
 else:
    text=(fixtures/'mocker/dashboard-validation/mocker.yaml').read_text().replace('Team: Checkout',f'Team: {case}').replace('IsLocalhost: false','IsLocalhost: true')
    text=text.replace('  System:', '  ExtraLabels:\n    Project: Signoff\n  System:')
    if kind=='invalid':
        cert=d/'invalid.pfx';cert.write_text('synthetic invalid PKCS12 contents')
        text=text.replace('IsSecuredSchema: false',f'IsSecuredSchema: true\n      CertificatePath: {cert}\n      CertificatePassword: synthetic-only')
    cfg=d/'mocker.yaml';cfg.write_text(text)
    args=['run',str(cfg),'--no-env']+([] if kind=='invalid' else ['--run-locally'])
    expected=1
 env=os.environ.copy();env['QAAS_USAGE_ENABLED']=str(q).lower()
 env.pop('QAAS_USAGE_FLUSH_MS',None)
 if flush is not None:env['QAAS_USAGE_FLUSH_MS']=str(flush)
 start=time.monotonic()
 cmd=['dotnet',str(binary),*args,'--send-logs','--elastic-uri',relay.url]
 with (d/'output.log').open('wb') as out:
    proc=subprocess.Popen(cmd,cwd=d,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT)
    watchdog=threading.Timer(45,proc.kill);watchdog.start()
    try:
        _, status, usage=os.wait4(proc.pid,0)
        elapsed=time.monotonic()-start
        proc.returncode=os.waitstatus_to_exitcode(status)
    finally:
        watchdog.cancel()
 if ((proc.returncode!=0)!=(kind=='invalid')):
    raise RuntimeError((p,proc.returncode,(d/'output.log').read_text(errors='replace')[-2500:]))
 time.sleep(max(delay,.075))
 record={'kind':kind,'product':p,'prior':prior,'enabled':q,'owner':case,'elapsed_s':elapsed,'exit':proc.returncode,
         'rss_kib':usage.ru_maxrss,'intended_attempts':expected,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
         'configured_flush_ms':flush,'receipt':relay.ledger.snapshot()}
 with report.open('a') as f:f.write(json.dumps(record)+'\n')
 return record
def good(p,v):
    rows=v['receipt']['usage_samples']
    start={r['AttemptId'] for r in rows if r['QaasEvent']==p+'ExecutionStarted'}
    end={r['AttemptId'] for r in rows if r['QaasEvent']==p+'ExecutionFinished'}
    e=v['intended_attempts'] if v['enabled'] else 0
    accepted=v['receipt']['accepted']
    return len(start)==len(end)==e and start==end and accepted.get(p+'ExecutionStarted',0)==accepted.get(p+'ExecutionFinished',0)==e
def stats(p,n):
    pairs=[]
    for i in range(n):
      pair={}
      for q in (False,True) if i%2==0 else (True,False):
        with Relay(0,0) as relay:
          pair[q]=one(p,'short',q,relay)
      pairs.append(pair)
      print(p,i+1,round(pair[False]['elapsed_s'],3),round(pair[True]['elapsed_s'],3),good(p,pair[True]),flush=True)
    out={}
    critical=2.131 if n==16 else 2.365 if n==8 else 2.262
    for key in ('elapsed_s','rss_kib'):
      diffs=[math.log(x[True][key]/x[False][key]) for x in pairs]
      mean=statistics.mean(diffs);delta=critical*statistics.stdev(diffs)/(len(diffs)**.5)
      out[key]=[round(100*math.expm1(x),3) for x in (mean,mean-delta,mean+delta)]
    print('SUMMARY',p,json.dumps({'pairs':n,'complete_enabled':sum(good(p,x[True]) for x in pairs),'complete_disabled':sum(good(p,x[False]) for x in pairs),'relative_change_percent_and_95_ci':out}),flush=True)
def raw_readback():
    rows=[json.loads(l) for l in report.read_text().splitlines()]
    requests.post(es+'/qaas-20*/_refresh',timeout=15).raise_for_status()
    for row in rows:
      res=requests.post(es+'/qaas-20*/_search',json={'size':100,'query':{'term':{'fields.Team.keyword':row['owner']}}},timeout=15)
      res.raise_for_status()
      data=[h['_source']['fields'] for h in res.json()['hits']['hits'] if h['_source']['fields'].get('QaasEvent')]
      assert collections.Counter(d['QaasEvent'] for d in data)==collections.Counter({k:v for k,v in row['receipt']['accepted'].items() if v and k!='(diagnostic)'}),(row['owner'],data,row['receipt']['accepted'])
    print('Raw-index readback matched relay receipts for',len(rows),'launches',flush=True)
report.unlink(missing_ok=True)
if '--budget-only' in sys.argv:
    schedules=[[0,32,75,125],[32,125,0,75],[75,0,125,32],[125,75,32,0]]
    res={b:[] for b in (0,32,75,125)}
    for schedule in schedules:
      for budget in schedule:
        with Relay(0,0) as r: res[budget].append(one('Mocker','short',True,r,flush=budget))
    for budget,rows in sorted(res.items()):
      print('BUDGET',budget,sum(good('Mocker',v) for v in rows),'/',len(rows),'median exit ms',round(1000*statistics.median(v['elapsed_s'] for v in rows)),flush=True)
elif '--failures-only' not in sys.argv:
    for product in ('Runner','Mocker'): stats(product,16)
else:
    for prior in (True,False):
      for s in range(4):
        for label,delay in (('healthy',0),('delayed',.4)):
          with Relay(0,delay) as r:
            v=one('Mocker','invalid',True,r,prior=prior,delay=delay+.15)
            log=(where/v['owner']/'output.log').read_text(errors='replace')
            assert 'HttpServer' in log and 'Execution.Start' in log,log[-2500:]
            print('Mocker invalid',prior,label,s+1,good('Mocker',v),flush=True)
if '--budget-only' in sys.argv:
    subprocess.run([sys.executable,str(root/'lab/read_budget.py')],check=True)
else:
    raw_readback()
