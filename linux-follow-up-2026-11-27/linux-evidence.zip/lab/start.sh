set -eu
mkdir -p lab/es-${QAASTAG:-cutover}-data lab/es-${QAASTAG:-cutover}-logs lab/grafana-${QAASTAG:-cutover}-data/plugins
ES_JAVA_OPTS="-Xms512m -Xmx512m -XX:ActiveProcessorCount=4" lab/elasticsearch-7.17.29/bin/elasticsearch -Eingest.geoip.downloader.enabled=false -Ediscovery.type=single-node -Enetwork.host=127.0.0.1 -Ehttp.port=19278 -Etransport.port=19378 -Expack.security.enabled=false -Epath.data="$PWD/lab/es-${QAASTAG:-cutover}-data" -Epath.logs="$PWD/lab/es-${QAASTAG:-cutover}-logs" >logs/es-lab.log 2>&1 &
p1=$!
G="$PWD/lab/grafana-v11.6.0"
GF_SERVER_HTTP_ADDR=127.0.0.1 GF_SERVER_HTTP_PORT=13000 GF_PATHS_DATA=$PWD/lab/grafana-${QAASTAG:-cutover}-data GF_PATHS_LOGS=$PWD/lab/grafana-${QAASTAG:-cutover}-data GF_ANALYTICS_REPORTING_ENABLED=false GF_ANALYTICS_CHECK_FOR_UPDATES=false GF_ANALYTICS_CHECK_FOR_PLUGIN_UPDATES=false GF_PLUGINS_PREINSTALL_DISABLED=true "$G/bin/grafana" server --homepath "$G" >logs/grafana-lab.log 2>&1 &
p2=$!
trap 'kill "$p1" "$p2" 2>/dev/null || true; wait "$p1" "$p2" 2>/dev/null || true' EXIT
for ((i=0;i<80;i++)); do
 if curl -fsS http://127.0.0.1:19278/_cluster/health >/dev/null 2>&1 &&
    curl -fsS http://127.0.0.1:13000/api/health >/dev/null 2>&1; then break; fi
 sleep 1
done
curl -fsS http://127.0.0.1:19278/_cluster/health >/dev/null
curl -fsS http://127.0.0.1:13000/api/health >/dev/null
"$@"
