# Runner phase study on Windows

The primary measure is real wall time from launching the CLI until Windows signals exit. Compare the identical Runner, entry assembly and Framework DLLs with `QAAS_USAGE_ENABLED=true` or `false`. Use the original five-plan fixture, the same paths and working directory, one `act` and four case-expanded `run` plans, and the existing native Elasticsearch sink via the healthy local forwarding relay. Record an independent OS process lifetime using `GetProcessTimes` creation and exit timestamps.

Fix 40 physical OFF/ON pairs before starting. Each adjacent group of two pairs contains both launch orders. `Random(2026112537)` selects the first of those orders. Two additional launches prime the single host and transport and are stored separately. `design.json`, written before the first launch, records the complete order, binary and fixture hashes, relay hash and command. A different product candidate requires explicit independent binary pins. Run serially after other benchmark/build activity stops. Keep every timed launch and every validation issue. Missing pairs invalidate a 40-pair estimate. A failed execution or receipt makes the healthy-workload claim inconclusive, even when all wall times were captured.

The first marker is the existing `Running Act execution with executionId` information diagnostic in `Execution.Start`. Its source precedes plan resolution and `ExecutionUsage.Start`, which contains the only explicit Runner branch on `QAAS_USAGE_ENABLED`. The outer `ExecuteLoader` calls `EnrichedBuild(addEnvironmentVariables: true)` and may enumerate environment values during configuration. None of these fixed YAMLs refers to the switch. Both nested commands use `--no-env`. Interpret time preceding the first marker as a same-binary negative control for the usage branch. It includes startup and configuration work. It can still contain arm-order or host effects.

An external pipe reader timestamps the first execution, the existing `Finished running executions. Aggregated exit code` line, and `Runner completed. ExitCode=0`. A separate thread waits on the real OS process handle. Markers come from receipt of existing output, with scheduling and pipe latency; the test adds no callback, profiler or output line inside Runner. Windows cumulative user and kernel CPU snapshots use `GetProcessTimes`. CPU values are quantized and short phases can report zero. Kernel process lifetime cross-checks full wall. All five plans and cleanup are visible, including post-plan teardown before the final CLI message and the tail to process exit.

Report whole-process paired geometric ON/OFF change and its two-sided 95% Student interval. The prespecified secondary estimator is `100 × mean[(ON exit − ON first execution) − (OFF exit − OFF first execution)] / mean[OFF whole CLI]`. Also report the numerator in milliseconds, phases and CPU separately. For both estimates, the primary interval uses 20 independent order-balanced two-pair groups (19 degrees of freedom). The ratio-of-means interval uses paired numerator/denominator influence values. A 40-pair interval (39 degrees of freedom) is reported as a sensitivity analysis. The phase estimate addresses work observed after the first pre-usage marker; only the full measurement answers the operational 2% question.

Compare all ordinary console log counts and ordinary Elastic message-template histograms within each pair. Capture emitted and accepted document counts, distinct matched IDs, uncompressed document and bulk bytes, compressed wire bytes, and bulk arrival and acknowledgement times against the process markers. Require ten accepted ordinary records in every launch, with five distinct starts and five matching successful finishes when enabled. The timeout and relay reconciliation are outside the ordinary exit stopwatch except when the application itself waits on the native sink. Raw debug text, case/host identities and credentials are omitted from result rows.

From this directory, start one study after candidate selection. These are the two alternative commands.

```powershell
python runner_phase.py --candidate 3797120 --output ../runner-phase-3797120
python runner_phase.py --candidate 320b05b --output ../runner-phase-320b05b
```

Analyze the selected output with `python runner_phase_report.py ../runner-phase-3797120` or `python runner_phase_report.py ../runner-phase-320b05b`. `--lab <workspace>` relocates the receipt relay and fixtures. `--host <absolute-path-to-QaaS.Runner.E2ETests.dll>` can point to an alternate physical copy; its entry, runtime and Framework hashes must still match the selected registered build. All three are verified before collection and after the last launch. The selected full commit and binary paths/hashes are saved in `design.json`.

| Candidate | Release entry SHA-256 | Runner runtime SHA-256 |
|---|---|---|
| `3797120` | `3DA0C853736B891519491097D8F84B58D3670768CC52A846F636737F7802068E` | `B43C4CB14B97B6AF02598F38FEC0ACB3C6815137C05A6A1F4DA3ED74963187AB` |
| `320b05b` | `4E77E73BF1A8011FFF797FE3A816F3135D30243826B61E50615D7E1FCEAF5FF1` | `B4CB00B105324129B2B1A29F6EC592DC20A91FAB559E08CCB970A0A38FEC9E1D` |

The Framework SHA-256 is `115F3AC1CBC86EB3829D8CBB65B7CA46DD5181B338C8DA8385E4A9A82F0C09FF` for both. The original relay is `revision-bench/relay.py`; it forwards loopback port 19379 to real Elasticsearch on port 19278. The original batch/case files remain in `revision-bench/phase-identical-batch.yaml`, `revision-bench/FixedOwnerPhase.yaml` and `bench/cases/`.
