# Five-plan Runner phase results

**The study did not establish the requested 2% whole-process ceiling.** Forty paired Windows CLI runs measured a geometric wall-time change of **+4.04%** with usage enabled, with a two-sided 95% interval of **−5.84% to +14.96%**. The complete CLI averaged 3,084.71 ms disabled and 3,237.05 ms enabled. The prespecified comparison after the first execution marker measured **+79.73 ms** (+18.14 to +141.32 ms), equivalent to **+2.58% of full disabled wall time** (+0.64% to +4.53%).

All 80 timed launches used canonical commit `320b05b7e7ce080bf1f75a3b4e49706edd5ae473`. The runtime, entry and Framework files matched the same three pinned SHA-256 digests in both arms. An additional enabled and disabled launch served as primers. Every timed launch completed one `act` and four `run` plans, exited zero and passed receipt, marker and diagnostic checks. All 40 physical pairs enter the analysis. Confidence calculations group adjacent opposite-order pairs into 20 randomized order-balanced blocks.

| Observed wall interval | Disabled mean | Enabled mean | Paired absolute change, 95% CI |
|---|---:|---:|---:|
| Launch to first execution, before the explicit usage branch | 2,754.28 ms | 2,826.89 ms | +72.61 ms [−255.06, +400.28] |
| First execution through completion of all five plans | 167.68 ms | 180.17 ms | +12.49 ms [−27.63, +52.62] |
| End of plans to final CLI diagnostic | 122.85 ms | 176.34 ms | +53.50 ms [+14.02, +92.97] |
| Final CLI diagnostic to actual process exit | 39.90 ms | 53.64 ms | +13.74 ms [+3.56, +23.92] |
| First execution to actual exit | 330.43 ms | 410.15 ms | +79.73 ms [+18.14, +141.32] |

The negative control before the first execution changed by +2.35% of full disabled time [−8.38%, +13.08%]. The five plans alone changed by +0.41% [−0.90%, +1.71%] on the same denominator. Child CPU after the first execution changed by +50.0 ms [−11.2, +111.2]. The full-process geometric ratio and the secondary arithmetic phase differences use different estimators. The pair-only sensitivity analysis for the full ratio gave +4.04% [−4.15%, +12.94%].

Both arms delivered 400 ordinary Elasticsearch records, with identical message-template histograms in every pair, and 4,880 ordinary console records. The enabled arm delivered 200 starts and 200 finishes with 200 distinct matched attempt IDs. Mean uncompressed bulk size rose from 4,668 to 11,469 bytes and compressed request bodies from 599 to 1,130 bytes. The relay received the last successful bulk acknowledgement after plan completion in every timed process.

An exploratory split of the longer teardown measured +25.21 ms [+0.68, +49.74] from plan completion to the last bulk acknowledgement and +28.29 ms [+3.51, +53.06] from that acknowledgement to the final CLI diagnostic. The change in summed relay request duration was +13.41 ms [−8.41, +35.22]. These markers include native provider work, scheduling and shutdown. They do not identify a specific change that would retain delivery while eliminating the remaining cost.
