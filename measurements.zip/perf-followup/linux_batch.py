"""Independent Linux whole-CLI replication with Docker startup outside the timer."""
from pathlib import Path
import hashlib,json,os,random,re,shutil,subprocess,sys,time
import requests
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
NAME='qaas-followup-runner-'+str(os.getpid())
team=NAME.replace('-','')
def docker(*args):
    return subprocess.check_output(['docker',*map(str,args)],encoding='utf8',errors='replace').strip()
def exe(script,*args):
    return docker('exec',NAME,'bash','-ec',script,'bash',*args)
def main():
    reps=int(sys.argv[1]); slug=sys.argv[2]; out=HERE/(slug+'.jsonl')
    assert not out.exists()
    fdir=HERE/('linux-fixture-'+str(os.getpid()));fdir.mkdir()
    (fdir/'plan.yaml').write_text((ROOT/'bench/short.qaas.yaml').read_text().replace('PerfLab',team),encoding='utf8')
    shutil.copytree(ROOT/'bench/cases',fdir/'cases')
    (fdir/'batch.yaml').write_text('Commands:\n  - Id: Prepare\n    Command: act /work/plan.yaml --no-env\n  - Id: FourCases\n    Command: run /work/plan.yaml --no-env --cases /work/cases\n',encoding='utf8')
    dirs={b:ROOT/(('RunnerBase' if b=='base' else 'Runner')+'/QaaS.Runner.E2ETests/bin/Release/net10.0') for b in ('base','head')}
    arms=['base-off','head-on','head-off']
    rng=random.Random(8104)
    try:
        docker('run','-d','--name',NAME,'--memory','400m','--cpuset-cpus','2,3','--network','qaas-pr45-local','mcr.microsoft.com/dotnet/runtime:10.0','sleep','infinity')
        exe('mkdir -p /base /head /work')
        for b,d in dirs.items(): docker('cp',str(d)+os.sep+'.',NAME+':/'+b)
        docker('cp',str(fdir)+os.sep+'.',NAME+':/work')
        hashes={b:exe('sha256sum /'+b+'/QaaS.Runner.dll').split()[0] for b in dirs}
        assert all(hashes[b]==hashlib.sha256((d/'QaaS.Runner.dll').read_bytes()).hexdigest() for b,d in dirs.items())
        print('linux',exe('dotnet --list-runtimes'),hashes,flush=True)
        def run(arm,block):
            b,s=arm.split('-')
            script="""cd /work; export QAAS_USAGE_ENABLED="$1"; TIMEFORMAT='%R %U %S'; { time dotnet "/$2/QaaS.Runner.E2ETests.dll" execute /work/batch.yaml --send-logs --elastic-uri http://qaas-pr78-es:9200 >/tmp/runner.log 2>&1; } 2>/tmp/runner.time; cat /tmp/runner.time; grep -c 'Running Act execution with executionId' /tmp/runner.log; grep -c 'Running Run execution with executionId' /tmp/runner.log"""
            result=exe(script,'true' if s=='on' else 'false',b).splitlines()
            assert result[-2:]==['1','4'],result
            wall,user,kernel=map(float,result[0].strip().split())
            row=dict(arm=arm,round=block,wall_s=wall,cpu_s=user+kernel,child_user_s=user,child_kernel_s=kernel,sha=hashes[b])
            file=out if block else out.with_suffix('.primer.jsonl')
            with file.open('a',encoding='utf8') as f:f.write(json.dumps(row)+'\n')
            print(block,arm,wall,flush=True)
        for arm in arms:run(arm,0)
        for first in range(0,reps,len(arms)):
            order=list(arms);rng.shuffle(order);shifts=list(range(len(arms)));rng.shuffle(shifts)
            for i,shift in enumerate(shifts[:reps-first]):
                for arm in order[shift:]+order[:shift]:run(arm,first+i+1)
        es='http://127.0.0.1:19278/qaas-20*'
        requests.post(es+'/_refresh',timeout=20).raise_for_status()
        body=dict(size=0,track_total_hits=True,query={'term':{'fields.Team.keyword':team}},aggs={'events':{'terms':{'field':'fields.QaasEvent.keyword','missing':'(diagnostic)'}}})
        reply=requests.post(es+'/_search',json=body,timeout=20);reply.raise_for_status()
        counts={e['key']:e['doc_count'] for e in reply.json()['aggregations']['events']['buckets']}
        print('accepted',counts,flush=True)
        expected={'(diagnostic)':(reps+1)*30,'RunnerExecutionStarted':(reps+1)*5,'RunnerExecutionFinished':(reps+1)*5}
        out.with_suffix('.receipts.json').write_text(json.dumps(dict(team=team,accepted=counts,expected=expected,hashes=hashes)))
        assert counts==expected,(counts,expected)
    finally:
        subprocess.run(['docker','rm','-f',NAME],stdout=subprocess.DEVNULL)
if __name__=='__main__':main()
