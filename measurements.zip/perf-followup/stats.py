"""Report blocked log-ratios with two-sided t intervals on paired observations."""
import collections, csv, json, math, statistics, sys
from pathlib import Path
root = Path(__file__).resolve().parent
t95 = [0,12.706,4.303,3.183,2.776,2.571,2.447,2.365,2.306,2.262,2.228,2.201,2.179,2.160,2.145,2.131,2.120,2.110,2.101,2.093,2.086,2.080,2.074,2.069,2.064,2.060,2.056,2.052,2.048,2.045,2.042]
def compare(file):
    blocks = collections.defaultdict(dict)
    rows = [json.loads(line) for line in file.read_text(encoding='utf8').splitlines()]
    for row in rows:
        assert row['arm'] not in blocks[row['round']]
        blocks[row['round']][row['arm']] = row
    labels = sorted({r['arm'] for r in rows})
    for left, right in [('prior-off','prior-on'),('base-off','head-on'),('prior-on','head-on'),('head-off','head-on'),('prior-off','head-on'),('base-off','head-off'),('head-off','control-off'),('prior-off','controlprior-off'),('head-on','head-ms32'),('head-on','head-ms75'),('stock-on','lean-on'),('stock-off','stock-on'),('lean-off','lean-on'),('head-on','next-on'),('next-off','next-on'),('base-off','next-on'),('head-off','next-off')]:
        if not {left,right}.issubset(labels):continue
        pairs = [(v[left],v[right]) for v in blocks.values() if {left,right}.issubset(v)]
        for key in ('wall_s','cpu_s','peak_bytes','peak_private'):
            if not pairs or any(key not in a or key not in b for a,b in pairs): continue
            l,r = zip(*[(a[key],b[key]) for a,b in pairs])
            logs=[math.log(y/x) for x,y in zip(l,r)]
            df=len(logs)-1
            if df<1:continue
            # Conservative for more than 30 df.
            width=t95[min(df,30)] * statistics.stdev(logs)/math.sqrt(len(logs))
            m=statistics.mean(logs)
            pct,low,hi=[round(100*math.expm1(x),3) for x in (m,m-width,m+width)]
            yield dict(file=file.name,reference=left,candidate=right,metric=key,pairs=len(logs),off_median=statistics.median(l),on_median=statistics.median(r),pct=pct,low=low,high=hi)
if __name__=='__main__':
    results=[r for name in sys.argv[1:] for r in compare(Path(name))]
    if results:
        writer=csv.DictWriter(sys.stdout,fieldnames=results[0]);writer.writeheader();writer.writerows(results)
