"""Time the stock Windows Runner CLI against the existing local Elasticsearch relay."""
import argparse
import collections
import ctypes
from ctypes import wintypes
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import random
import re
import subprocess
import sys
import threading
import time


ROOT = Path(__file__).resolve().parents[2]
SEED = 2026112537
PAIRS = 40
EXPECTED = {
    'QaaS.Runner.E2ETests.dll': '3da0c853736b891519491097d8f84b58d3670768cc52a846f636737f7802068e',
    'QaaS.Runner.dll': 'b43c4cb14b97b6af02598f38fec0acb3c6815137c05a6a1f4da3ed74963187ab',
    'QaaS.Framework.Executions.dll': '115f3ac1cbc86eb3829d8cbb65b7ca46dd5181b338c8da8385e4a9a82f0c09ff',
}
BUILDS = {
    '3797120': ('37971206388a1e976d32e61736b23c3968062d57', 'Runner', EXPECTED),
    '320b05b': ('320b05b7e7ce080bf1f75a3b4e49706edd5ae473', 'perf-followup/RunnerEmptyGenerator', {
        **EXPECTED,
        'QaaS.Runner.E2ETests.dll': '4e77e73bf1a8011fff797fe3a816f3135d30243826b61e50615d7e1fceaf5ff1',
        'QaaS.Runner.dll': 'b4cb00b105324129b2b1a29f6ec592dc20a91fab559e08ccb970a0a38fec9e1d',
    }),
}
INFO = re.compile(rb'^\[\d\d:\d\d:\d\d [A-Z]{3}\] ')
START = 'RunnerExecutionStarted'
FINISH = 'RunnerExecutionFinished'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def schedule():
    rng = random.Random(SEED)
    orders = []
    for _ in range(PAIRS // 2):
        first = ('off', 'on') if rng.getrandbits(1) else ('on', 'off')
        orders.extend([first, first[::-1]])
    return orders


def get_times(proc):
    stamps = [wintypes.FILETIME() for _ in range(4)]
    succeeded = ctypes.windll.kernel32.GetProcessTimes(
        wintypes.HANDLE(int(proc._handle)), *(ctypes.byref(v) for v in stamps))
    if not succeeded:
        raise ctypes.WinError()
    return tuple((v.dwHighDateTime << 32) | v.dwLowDateTime for v in stamps)


def mark(proc, origin):
    wall = (time.perf_counter_ns() - origin) / 1e6
    _, _, kernel, user = get_times(proc)
    return {'wall_ms': wall, 'cpu_ms': (kernel + user) / 10000,
            'kernel_ms': kernel / 10000, 'user_ms': user / 10000}


def bulk_templates(captured):
    templates = collections.Counter()
    for body, coding, response, response_coding in captured:
        if 'gzip' in coding.lower():
            body = gzip.decompress(body)
        if 'gzip' in response_coding.lower():
            response = gzip.decompress(response)
        docs = body.splitlines()[1::2]
        items = json.loads(response).get('items', [])
        for doc, item in zip(docs, items, strict=True):
            data = json.loads(doc)
            status = next(iter(item.values()))['status']
            if 200 <= status < 300 and not data.get('fields', {}).get('QaasEvent'):
                template = data.get('messageTemplate') or data.get('MessageTemplate')
                templates[template or '(missing messageTemplate)'] += 1
    return dict(templates)


def one(arm, pair, ordinal, relay, host, fixture, cwd):
    command = ['dotnet', str(host), 'execute', str(fixture), '--send-logs', '--elastic-uri', relay.url]
    env = {**os.environ, 'QAAS_USAGE_ENABLED': 'true' if arm == 'on' else 'false'}
    seen = collections.Counter()
    markers = {}
    failures = []
    stdout_bytes = 0
    reader_error = []
    timed_out = False
    utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    relay_clock_offset = time.perf_counter() - time.monotonic()
    origin = time.perf_counter_ns()
    with subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT) as proc:
        def read_output():
            nonlocal stdout_bytes
            try:
                for line in proc.stdout:
                    # Catch the first execution notification before doing any other work on that line.
                    if b'Running Act execution with executionId' in line:
                        if 'first_execution' not in markers:
                            markers['first_execution'] = mark(proc, origin)
                        seen['act'] += 1
                    elif b'Running Run execution with executionId' in line:
                        seen['run'] += 1
                    elif b'Finished running executions. Aggregated exit code:' in line:
                        markers['plans_finished'] = mark(proc, origin)
                        seen['plans_finished'] += 1
                    elif b'Runner completed. ExitCode=0' in line:
                        markers['cli_finished'] = mark(proc, origin)
                        seen['cli_finished'] += 1
                    stdout_bytes += len(line)
                    seen['lines'] += 1
                    if INFO.match(line) and b'RunnerExecutionStarted' not in line and b'RunnerExecutionFinished' not in line:
                        seen['ordinary_console_records'] += 1
            except Exception as exc:
                reader_error.append(type(exc).__name__)

        reader = threading.Thread(target=read_output, name='Runner diagnostic pipe')
        reader.start()
        try:
            proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            proc.kill()
            proc.wait()
        # This uses the process handle and is independent of pipe EOF or relay acknowledgement.
        markers['exit'] = mark(proc, origin)
        creation, exit_stamp, _, _ = get_times(proc)
        os_lifetime_ms = (exit_stamp - creation) / 10000
        reader.join()
        exit_code = proc.returncode
    if reader_error or exit_code or timed_out:
        failures.append(dict(reader=reader_error, exit_code=exit_code, timeout=timed_out))
    if (seen['act'], seen['run'], seen['plans_finished'], seen['cli_finished']) != (1, 4, 1, 1):
        failures.append('unexpected diagnostic sequence/count')
    labels = ['first_execution', 'plans_finished', 'cli_finished', 'exit']
    if any(name not in markers for name in labels) or any(
        markers[a]['wall_ms'] > markers[b]['wall_ms'] for a, b in zip(labels, labels[1:])
    ):
        failures.append('missing or late external marker')
    expected = {'(diagnostic)': 10, **({START: 5, FINISH: 5} if arm == 'on' else {})}
    # The exit clock is already closed. Wait for outstanding genuine Elastic acknowledgements outside the timer.
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        receipt = relay.ledger.snapshot()
        if receipt['accepted'] == expected:
            break
        time.sleep(.025)
    time.sleep(.15)
    receipt = relay.ledger.snapshot()
    events = receipt['usage_samples']
    starts = {ev['AttemptId'] for ev in events if ev.get('QaasEvent') == START}
    ends = {ev['AttemptId'] for ev in events if ev.get('QaasEvent') == FINISH}
    if receipt['accepted'] != expected or receipt['emitted'] != expected or (arm == 'on' and (len(starts) != 5 or starts != ends)):
        failures.append('Elastic event or attempt reconciliation failed')
    terminal = [ev for ev in events if ev.get('QaasEvent') == FINISH]
    if arm == 'on' and (collections.Counter(ev.get('ExecutionType') for ev in terminal) != {'Act':1,'Run':4}
                        or any(ev.get('Outcome') != 'success' for ev in terminal)):
        failures.append('unexpected terminal phase/outcome')
    templates = bulk_templates(relay.ledger.bulks)
    if sum(templates.values()) != 10 or '(missing messageTemplate)' in templates:
        failures.append('ordinary Elastic template reconciliation failed')
    # No raw messages, case names, machine identities or credentials enter the receipt.
    return dict(pair=pair, ordinal=ordinal, arm=arm, utc=utc, exit_code=exit_code, timeout=timed_out,
                markers=markers, os_lifetime_ms=os_lifetime_ms, observed=dict(seen), stdout_bytes=stdout_bytes,
                accepted=receipt['accepted'], emitted=receipt['emitted'], ordinary_templates=templates,
                matched_attempts=len(starts & ends), wire_bytes=receipt['wire_body_bytes'], ndjson_bytes=receipt['ndjson_bytes'],
                document_bytes=receipt['document_bytes'], bulk_posts=receipt['posts'],
                bulk_timeline=[{'arrived_ms':1000*(t['t'] + relay_clock_offset - origin/1e9),
                                'acked_ms':1000*(t['ack'] + relay_clock_offset - origin/1e9),
                                'documents':t['documents'], 'status':t['status'], 'errors':t['errors']}
                               for t in receipt['timeline']],
                bulk_ack_ms=[1000*(t['ack']-t['t']) for t in receipt['timeline']], quality_issues=failures)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--lab', type=Path, default=ROOT)
    parser.add_argument('--candidate', choices=BUILDS.keys(), default='3797120', help='Select immutable registered entry/runtime/Framework hashes')
    parser.add_argument('--host', type=Path, help='Optional real Runner E2E entry path; must match all registered hashes')
    args = parser.parse_args()
    if os.name != 'nt':
        raise RuntimeError('Windows GetProcessTimes is required.')
    root = args.lab.resolve()
    sys.path.insert(0, str(root/'revision-bench'))
    from relay import Relay, Ledger
    class CaptureLedger(Ledger):
        def __init__(self):
            super().__init__()
            self.bulks = []
        def record(self, path, method, status, raw, encoding, response, response_encoding, t):
            if 200 <= status < 300 and path.rstrip('/').endswith('/_bulk'):
                self.bulks.append((raw, encoding, response, response_encoding))
            super().record(path, method, status, raw, encoding, response, response_encoding, t)

    if os.environ.get('DOTNET_STARTUP_HOOKS') or any(os.environ.get(n) == '1' for n in ('CORECLR_ENABLE_PROFILING','COR_ENABLE_PROFILING','DOTNET_DefaultDiagnosticPortSuspend')):
        raise RuntimeError('Remove runtime startup/profiling overrides for this study.')
    cwd = root/'revision-bench'
    source_sha, checkout, expected = BUILDS[args.candidate]
    host = args.host.resolve() if args.host else root/checkout/'QaaS.Runner.E2ETests/bin/Release/net10.0/QaaS.Runner.E2ETests.dll'
    if host.name != 'QaaS.Runner.E2ETests.dll':
        raise ValueError('Unexpected Runner CLI entry file.')
    fixture = cwd/'phase-identical-batch.yaml'
    files = [fixture, cwd/'FixedOwnerPhase.yaml', *(root/'bench/cases').glob('*.yaml')]
    def inputs():
        return {'binaries':{name:digest(host.parent/name) for name in EXPECTED},
                'fixtures':{file.name:digest(file) for file in files}, 'relay':digest(cwd/'relay.py')}
    fingerprint = inputs()
    if fingerprint['binaries'] != expected or len(files) != 6:
        raise RuntimeError('Unexpected Runner build or fixture inventory.')
    if any(b'QAAS_USAGE_ENABLED' in file.read_bytes() for file in files):
        raise RuntimeError('Fixture refers to usage switch.')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    orders = schedule()
    (output/'design.json').write_text(json.dumps(dict(seed=SEED, pairs=PAIRS, orders=orders,source_sha=source_sha,
        fingerprint=fingerprint, launch=['dotnet',str(host),'execute',str(fixture),'--send-logs','--elastic-uri','http://127.0.0.1:19379']),indent=2))
    for pair, order in enumerate([('on','off'), *orders]):
        file = output/('primers.jsonl' if not pair else 'runs.jsonl')
        for ordinal, arm in enumerate(order,1):
            with Relay(19379,0) as relay:
                relay.ledger=CaptureLedger()
                row=one(arm,pair,ordinal,relay,host,fixture,cwd)
            with file.open('a',encoding='utf8') as stream:
                stream.write(json.dumps(row,sort_keys=True)+'\n')
            print(f'{pair:02d}/{PAIRS} {ordinal} {arm} {row["markers"]["exit"]["wall_ms"]:.1f} ms, issues={len(row["quality_issues"])}',flush=True)
    if inputs()!=fingerprint:
        raise RuntimeError('Binary, fixture or relay changed while measuring.')


if __name__ == '__main__':
    main()
