"""Summarize all 40 prespecified paired observations, including the 20 order-balanced clusters."""
import argparse
import collections
import json
import math
from pathlib import Path
from statistics import mean, stdev

from runner_phase import PAIRS, schedule


PHASES = {
    'whole_cli': (None, 'exit'),
    'before_first_execution': (None, 'first_execution'),
    'all_five_plans': ('first_execution', 'plans_finished'),
    'after_plans_to_cli_log': ('plans_finished', 'cli_finished'),
    'after_cli_log_to_os_exit': ('cli_finished', 'exit'),
    'after_first_execution_to_os_exit': ('first_execution', 'exit'),
}
T95 = {19: 2.093024054, 39: 2.02269092}


def blocks(values, size=2):
    return [mean(values[i:i+size]) for i in range(0, len(values), size)]


def ci(values):
    center=mean(values)
    half=T95[len(values)-1]*stdev(values)/math.sqrt(len(values))
    return {'estimate':center,'lower95':center-half,'upper95':center+half}


def scaled_difference(diffs, denominators, cluster):
    d,o=blocks(diffs,cluster),blocks(denominators,cluster)
    ratio=mean(d)/mean(o)
    # Paired ratio of means, with numerator/denominator variation kept together within each order-balanced block.
    influences=[100*(x-ratio*y)/mean(o) for x,y in zip(d,o,strict=True)]
    half=T95[len(d)-1]*stdev(influences)/math.sqrt(len(d))
    return {'estimate':100*ratio,'lower95':100*ratio-half,'upper95':100*ratio+half}


def phase(row, name, metric):
    first,last=PHASES[name]
    return row['markers'][last][metric]-(row['markers'][first][metric] if first else 0)


def summarize(rows):
    grouped=collections.defaultdict(dict)
    problems=[]
    for row in rows:
        p,a=row['pair'],row['arm']
        if a in grouped[p]:raise ValueError('Duplicate arm in a physical pair')
        grouped[p][a]=row
        if row['quality_issues']:problems.append([p,a,row['quality_issues']])
    if sorted(grouped)!=list(range(1,PAIRS+1)) or any(set(items)!={'on','off'} for items in grouped.values()):
        raise ValueError('All 40 complete physical pairs are required.')
    ordered=[grouped[p] for p in range(1,PAIRS+1)]
    for p,(items,order) in enumerate(zip(ordered,schedule(),strict=True),1):
        if tuple(sorted(items,key=lambda a:items[a]['ordinal']))!=order:raise ValueError('Arm order differs from registered design')
        if items['on']['ordinary_templates']!=items['off']['ordinary_templates']:
            problems.append([p,'both','ordinary Elastic template histograms differ'])
        if items['on']['observed'].get('ordinary_console_records')!=items['off']['observed'].get('ordinary_console_records'):
            problems.append([p,'both','ordinary console log counts differ'])
    timings={}
    for metric in ['wall_ms','cpu_ms','kernel_ms','user_ms']:
        denominator=[phase(p['off'],'whole_cli',metric) for p in ordered]
        timings[metric]={}
        for name in PHASES:
            off=[phase(p['off'],name,metric) for p in ordered]
            on=[phase(p['on'],name,metric) for p in ordered]
            diff=[b-a for a,b in zip(off,on,strict=True)]
            timings[metric][name]={'off_mean':mean(off),'on_mean':mean(on),
               'paired_change_ms':ci(blocks(diff)),
               'change_pct_full_off':scaled_difference(diff,denominator,2),
               'change_pct_full_off_pair_only_sensitivity':scaled_difference(diff,denominator,1)}
    whole=[math.log(phase(p['on'],'whole_cli','wall_ms')/phase(p['off'],'whole_cli','wall_ms')) for p in ordered]
    geom=lambda v:{k:100*math.expm1(x) for k,x in ci(v).items()}
    counts={}
    for arm in ('on','off'):
        part=[p[arm] for p in ordered]
        counts[arm]={}
        for key in ('matched_attempts','wire_bytes','ndjson_bytes','bulk_posts','stdout_bytes','os_lifetime_ms'):
            vals=[r[key] for r in part];counts[arm][key]={'mean':mean(vals),'min':min(vals),'max':max(vals)}
        for key in ('accepted','emitted','ordinary_templates','observed'):
            c=collections.Counter()
            for r in part:c.update(r[key])
            counts[arm][key]=dict(c)
    return {'pairs':len(ordered),'order_balanced_blocks':len(ordered)//2,'quality_issues':problems,
        'whole_cli_geometric_change_pct':geom(blocks(whole)), 'whole_cli_pair_only_sensitivity_pct':geom(whole),
        'phases':timings,'receipts':counts}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results',type=Path)
    args=parser.parse_args()
    report=summarize([json.loads(line) for line in (args.results/'runs.jsonl').read_text().splitlines()])
    (args.results/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('pairs','quality_issues','whole_cli_geometric_change_pct')},indent=2))
    print('Post-first-execution change as % of full OFF wall:',report['phases']['wall_ms']['after_first_execution_to_os_exit']['change_pct_full_off'])
