import argparse, secrets
from common import *

CASES={
 'runner-act':('Runner','act','short.qaas.yaml',[],0),
 'runner-assert':('Runner','assert','short.qaas.yaml',[],0),
 'runner-template':('Runner','template','short.qaas.yaml',[],0),
 'runner-cases':('Runner','run','short.qaas.yaml',['--cases',str(PREVIOUS/'cases')],0),
 'runner-batch':('Runner','execute','short.qaas.yaml',[],0),
 'runner-storage-fail':('Runner','act','broken-storage.qaas.yaml',[],'fail'),
 'runner-24-sessions':('Runner','run','busy.qaas.yaml',[],0),
 'runner-short':('Runner','run','short.qaas.yaml',[],0),
 'runner-high-assertion':('Runner','run','high-assertions.qaas.yaml',[],1),
 'runner-assertion-fail':('Runner','run','failed.qaas.yaml',[],1),
 'runner-unowned':('Runner','run','unowned.qaas.yaml',[],1),
 'runner-invalid':('Runner','run','malformed.qaas.yaml',[],'fail'),
 'mocker-short':('Mocker','run','mocker.qaas.yaml',['--run-locally'],0),
 'mocker-start-fail':('Mocker','run','mocker-failure.qaas.yaml',[],'fail'),
 'mocker-template':('Mocker','template','mocker.qaas.yaml',[],0),
 'mocker-literal-unknown':('Mocker','run','mocker.qaas.yaml',['--run-locally'],0),
 'mocker-unowned':('Mocker','run','mocker-unowned.qaas.yaml',['--run-locally'],0),
 'mocker-build-rejection':('Mocker','run','mocker-rejected.qaas.yaml',[],'fail'),
}
def timed(command,env,expected,logfile):
    s=time.perf_counter(); last={};peak_working=peak_private=0
    with logfile.open('wb') as logs,subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=logs,stderr=subprocess.STDOUT,env=env,cwd=ROOT) as proc:
        while proc.poll() is None:
            try:
                last=memory(proc)
                peak_working=max(peak_working,last['peak_working_set'])
                peak_private=max(peak_private,last['private'])
            except OSError:
                if proc.poll() is None: raise
            try:proc.wait(timeout=.05)
            except subprocess.TimeoutExpired:pass
            if time.perf_counter()-s > 160:
                proc.kill();proc.wait();raise TimeoutError(command)
        elapsed=time.perf_counter()-s
        if (expected=='fail' and proc.returncode==0) or (isinstance(expected,int) and proc.returncode!=expected):
            raise ValueError((command,expected,proc.returncode,logfile))
        return dict(exit=proc.returncode,wall_s=elapsed,cpu_s=cpu(proc),peak_working_set_bytes=peak_working,sampled_peak_private_bytes=peak_private,output_bytes=logs.tell())
def run(args):
    if args.out=='cli-runner-short.jsonl':
        (ROOT/'final-series-slot').touch()
        while not (ROOT/'final-series-done').exists():time.sleep(1)
    if args.out in ('cli-runner-final-slow.jsonl','cli-runner-extra.jsonl') and not (ROOT/'mocker-ownership-done').exists():
        (ROOT/'mocker-rebuild-slot').touch()
        while not (ROOT/'mocker-ownership-done').exists():time.sleep(1)
    if args.out=='cli-mocker-short.jsonl':
        (ROOT/'runner-retest-slot').touch()
        while not (ROOT/'runner-retest-done').exists():time.sleep(1)
    arms=json.loads((ROOT/args.arms).read_text(encoding='utf-8-sig'))
    for i in range(args.start,args.start+args.rounds):
        for mode in args.modes.split(','):
            for label in args.cases.split(','):
                repo,verb,src,base_flags,expected=CASES[label]
                for side in (['off','on'] if i%2 else ['on','off']):
                    arm=arms[side];build=arm['build']
                    with ExitStack() as stack:
                        relay=relay_for(stack,mode,19379)
                        owner='Measure'+secrets.token_hex(6)
                        fixture=high_assertions(owner,args.assertions) if src=='high-assertions.qaas.yaml' else named_fixture(src,owner)
                        if label=='mocker-literal-unknown':
                            fixture.write_text(fixture.read_text(encoding='utf8').replace('Team: '+owner,'Team: Unknown'),encoding='utf8')
                        if label=='runner-batch':
                            nested=ROOT/(owner+'-batch.yaml')
                            nested.write_text('Commands:\n  - Id: Prepare\n    Command: act '+fixture.as_posix()+' --no-env\n  - Id: FourCases\n    Command: run '+fixture.as_posix()+' --no-env --cases '+(PREVIOUS/'cases').as_posix()+'\n',encoding='utf8')
                            fixture=nested
                        flags=[*base_flags,*arm.get('args',[]),*arm.get(repo+'Args',[])]
                        command=base_command(repo,build,verb,fixture,mode,relay,flags)
                        if label=='runner-batch':command.remove('--no-env')
                        logdir=ROOT/'logs';logdir.mkdir(exist_ok=True)
                        outfile=logdir/(owner+'.log')
                        begin=now()
                        result=timed(command,{**os.environ,**arm.get('env',{}),**arm.get(repo+'Env',{})},expected,outfile)
                        ledger_at_exit=relay.ledger.snapshot() if relay else None
                        wait_for_bulk(relay)
                        ledger=relay.ledger.snapshot() if relay else None
                        assert_suppressed(arm,ledger)
                        if label in ('mocker-literal-unknown','mocker-unowned') and ledger:
                            for event in ledger['usage_samples']:
                                if 'TeamKnown' in event:assert event['TeamKnown']==(label=='mocker-literal-unknown'),event
                        if label=='runner-batch':
                            content=outfile.read_text(encoding='utf8',errors='replace')
                            result['act_observed']=content.count('Running Act execution with executionId');result['run_observed']=content.count('Running Run execution with executionId')
                            assert (result['act_observed'],result['run_observed'])==(1,4),outfile
                        if label=='runner-high-assertion':
                            # Verify actual invocation as well as fixture length. Retain the diagnostic source for older releases.
                            logs=outfile.read_text(encoding='utf8',errors='replace')
                            unique=sum(f'ExpectedFailure{x:04d}' in logs for x in range(args.assertions))
                            if unique!=args.assertions:raise ValueError(f'Only {unique}/{args.assertions} assertion names visible in {outfile}')
                            runner_terminal(ledger,unique)
                            result.update(assertions_observed=unique,assertions_per_s=unique/result['wall_s'])
                        row=dict(begin=begin,end=now(),suite=args.label,mode=mode,case=label,side=side,round=i,owner=owner,
                                 command=command,files=metadata(repo,build),ledger=ledger,ledger_at_exit=ledger_at_exit,**result)
                        append(args.out,row)
                        print(i,label,mode,side,round(result['wall_s'],3),result['peak_working_set_bytes'],flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--label',required=True);p.add_argument('--arms',required=True);p.add_argument('--out',required=True)
    p.add_argument('--start',type=int,default=1);p.add_argument('--rounds',type=int,default=3)
    p.add_argument('--modes',default='disabled,healthy,slow,unreachable');p.add_argument('--cases',default=','.join(CASES))
    p.add_argument('--assertions',type=int,default=128)
    run(p.parse_args())
