from pathlib import Path
import ctypes, json, datetime, hashlib, os, signal, subprocess, time, urllib.request, sys
from ctypes import wintypes
from contextlib import ExitStack
from relay import Relay
ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent/'bench'
sys.path.insert(0,str(PREVIOUS))
from bench import assembly as original_assembly, binaries as original_binaries, cpu

def assembly(repo,build):
    if build!='previous':return original_assembly(repo,build)
    name='QaaS.Runner.E2ETests' if repo=='Runner' else 'QaaS.Mocker.Example'
    return ROOT/'previous'/repo/(name+'.dll')
def binaries(repo,build):
    if build!='previous':return original_binaries(repo,build)
    folder=assembly(repo,build).parent
    names=['QaaS.Runner.dll'] if repo=='Runner' else ['QaaS.Mocker.dll','QaaS.Mocker.Servers.dll']
    return {name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in names}


class Counters(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('page_faults',wintypes.DWORD),*[(field,ctypes.c_size_t) for field in ('peak_working_set','working_set','peak_paged','paged','peak_nonpaged','nonpaged','pagefile','peak_pagefile','private')]]
def memory(process):
    state=Counters(); state.cb=ctypes.sizeof(state)
    if not ctypes.windll.psapi.GetProcessMemoryInfo(wintypes.HANDLE(int(process._handle)),ctypes.byref(state),state.cb):
        raise ctypes.WinError()
    return {k:getattr(state,k) for k in ('peak_working_set','working_set','private')}

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def append(filename,row):
    with (ROOT/filename).open('a',encoding='utf8') as fp:fp.write(json.dumps(row,sort_keys=True)+'\n')
def owned(text,owner):
    return text.replace('Team: PerfLab','Team: '+owner+'\n  ExtraLabels:\n    Project: Performance')
def named_fixture(source,owner,flags=(),http=None):
    text=owned((PREVIOUS/source).read_text(encoding='utf8'),owner)
    if source=='high-assertions.qaas.yaml':
        raise ValueError('High assertion fixture is generated below')
    if http is not None:text=text.replace('Port: 19847','Port: '+str(http))
    target=ROOT/(owner+'.yaml')
    target.write_text(text,encoding='utf8')
    return target
def high_assertions(owner,count):
    template=(PREVIOUS/'failed.qaas.yaml').read_text(encoding='utf8')
    prefix,assertion=template.split('Assertions:\n',1)
    result=owned(prefix,owner)+'Assertions:\n'+''.join(assertion.replace('ExpectedFailure',f'ExpectedFailure{x:04d}') for x in range(count))
    target=ROOT/(owner+'.yaml');target.write_text(result,encoding='utf8');return target
def process_metrics(process):return {'cpu_s':cpu(process),**memory(process)}
def options(mode,relay=None):
    if mode=='disabled':return ['--disable-elastic-defaults']
    return ['--send-logs','--elastic-uri',relay.url if relay else 'http://127.0.0.1:19996']
def base_command(repo,build,verb,fixture,mode,relay,extra):
    return ['dotnet',str(assembly(repo,build)),verb,str(fixture),'--no-env',*options(mode,relay),*extra]
def assert_suppressed(arm,ledger):
    switch=arm.get('env',{}).get('QAAS_USAGE_ENABLED','').lower()
    if switch=='false' and ledger and any(k!='(diagnostic)' and n for k,n in ledger['accepted'].items()):
        raise AssertionError(('Usage escaped the off switch',ledger['usage_samples']))
def runner_terminal(ledger,assertions):
    for event in (ledger or {}).get('usage_samples',[]):
        if event.get('QaasEvent')=='RunnerExecutionFinished':
            if 'AssertionsExecuted' in event and event['AssertionsExecuted']!=assertions:
                raise ValueError(('Wrong terminal assertion count',event,assertions))
            if 'TestsExecuted' in event and event['TestsExecuted']!=1:
                raise ValueError(('Wrong test count',event))
def wait_for_bulk(relay):
    # A bulk received before CLI exit may still complete after disconnect; observe it outside the timed interval.
    if relay:time.sleep(1.2 if relay.delay else .15)
def relay_for(stack,mode,port):
    return stack.enter_context(Relay(port,1 if mode=='slow' else 0)) if mode in ('healthy','slow') else None
def metadata(repo,build):
    return dict(runtime=binaries(repo,build),entry_hash=hashlib.sha256(assembly(repo,build).read_bytes()).hexdigest())
