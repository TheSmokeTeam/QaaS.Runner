import datetime as dt
import json
import re
import sys
from pathlib import Path
import requests
from canonical import ROOT,req,definitions
from dash import dims
HERE=Path(__file__).parent
G="http://127.0.0.1:13045"
client=requests.Session()
client.auth=("admin","admin")
def api(method,path,body=None):
    r=client.request(method,G+path,json=body,timeout=80)
    if not r.ok:raise RuntimeError(f"{path} {r.status_code} {r.text[:1800]}")
    return r.json()
def provision(p):
    uid="qaas-"+p.lower()+"-usage-v1"
    index="qaasusage-"+p.lower()+"-v1"
    body={"uid":uid,"name":"QaaS "+p+" reconciled","type":"elasticsearch","access":"proxy","url":"http://qaas-pr78-es:9200","database":index,
          "jsonData":{"index":index,"timeField":"event.Time","esVersion":"7.17.29","maxConcurrentShardRequests":2}}
    if not any(x["uid"]==uid for x in api("GET","/api/datasources")):api("POST","/api/datasources",body)
    d=json.loads((ROOT/p/"grafana"/(p.lower()+"-usage.json")).read_text())
    stored=client.get(G+"/api/dashboards/uid/"+d["uid"],timeout=20)
    if stored.ok and stored.json()["meta"].get("provisioned"):
        assert stored.json()["dashboard"]["panels"]==d["panels"] or [
            (p["title"],p.get("interval"),p.get("targets")) for p in stored.json()["dashboard"]["panels"]
        ]==[(p["title"],p.get("interval"),p.get("targets")) for p in d["panels"]]
        return stored.json()["dashboard"]
    api("POST","/api/dashboards/import",{"dashboard":d,"overwrite":True,"folderId":0,"inputs":[]})
    return api("GET","/api/dashboards/uid/"+d["uid"])["dashboard"]
def panel_frames(p,w,filters=None,datasource_uid=None):
    data=provision(p)
    bytitle={}
    lo,hi=w["start"],w["end"]
    filters=filters or {}
    enddate=dt.datetime.fromtimestamp(hi/1000,dt.timezone.utc).isoformat().replace("+00:00","Z")
    for panel in data["panels"]:
        if panel["type"]=="row":continue
        queries=json.dumps(panel["targets"]).replace("${__to:date:iso}",enddate).replace("${__from}",str(lo)).replace("${__to}",str(hi))
        for d in dims:
            value=filters.get(d)
            queries=queries.replace("${"+d+":lucene}",("\\\""+value+"\\\"") if value is not None else "*")
        qs=json.loads(queries)
        minimum=panel.get("interval")
        scale={"ms":1,"s":1000,"m":60000,"h":3600000,"d":86400000}
        match=re.fullmatch(r"(\d+)(ms|s|m|h|d)",minimum) if minimum else None
        if minimum and not match:raise ValueError("Unsupported panel interval "+str(minimum))
        minimum_ms=int(match[1])*scale[match[2]] if match else 0
        for q in qs:
            q.update(intervalMs=max(1000,int((hi-lo)/180),minimum_ms),maxDataPoints=180)
            if datasource_uid:q["datasource"]["uid"]=datasource_uid
        try:
            result=api("POST","/api/ds/query",{"queries":qs,"from":str(lo),"to":str(hi)})["results"]
            frames=[]
            for ref,res in result.items():
                if res.get("error"):raise ValueError(str(res["error"]))
                for f in res.get("frames",[]):
                    frames.append({"ref":ref,"name":f["schema"].get("name"),"cols":[field["name"] for field in f["schema"]["fields"]],"metadata":[{"labels":v.get("labels"),"display":v.get("config",{}).get("displayNameFromDS"),"interval":v.get("config",{}).get("interval")} for v in f["schema"]["fields"]],"values":f["data"]["values"]})
            bytitle[panel["title"]]=frames
            print(p,panel["title"],str([(f["cols"],[v[:5] for v in f["values"]]) for f in frames])[:360],flush=True)
        except Exception as e:
            print(p,panel["title"],"ERROR",str(e)[:2200],flush=True)
            bytitle[panel["title"]]={"error":str(e)}
    return bytitle
if __name__=="__main__":
    w=json.loads((HERE/(sys.argv[1]+"-window.json")).read_text())
    for p in sys.argv[2:] or ["Runner","Mocker"]:
        f=panel_frames(p,w,{"Version":"test"} if sys.argv[1]=="probe" else {"Version":w["versions"][p]})
        (HERE/(sys.argv[1]+"-"+p+"-frames.json")).write_text(json.dumps(f,indent=2),encoding="utf-8")
        if any(isinstance(v,dict) and "error" in v for v in f.values()):sys.exit(1)
