import json
import time
from contextlib import redirect_stdout
from pathlib import Path
from canonical import req
from check_charts import api,panel_frames
from oracle import oracle

HERE=Path(__file__).parent
folder=HERE/(HERE/"current-live.txt").read_text().strip()
receipt=json.loads((folder/"receipt.json").read_text())
events=json.loads((folder/"events.json").read_text())
window={"start":receipt["from"],"end":receipt["to"]}
assert len(receipt["witness"])==2 and receipt["quiet_batches"]==0 and len(receipt["http"])==8
out={}
for p in ["Runner","Mocker"]:
    sl=p.lower(); rows=[e["fields"] for e in events if e["fields"]["QaasEvent"].startswith(p)]
    ids=list({e["AttemptId"] for e in rows})
    index="qaasusage-"+sl+"-v1"
    alias="qaasverify-"+folder.name+"-"+sl
    req("POST","/_aliases",{"actions":[{"add":{"index":index,"alias":alias,"filter":{"terms":{"event.AttemptId":ids}}}}]})
    expected=len(ids)+len({(r["ServerId"],r["BatchSequence"]) for r in rows if r["QaasEvent"]=="MockerHttpRequests"})
    until=time.monotonic()+95
    finishes=sum(r["QaasEvent"]==p+"ExecutionFinished" for r in rows)
    while True:
        count=req("POST","/"+alias+"/_count")["count"]
        finished_count=req("POST","/"+alias+"/_count",{"query":{"exists":{"field":"event.FinishedAt"}}})["count"]
        if count==expected and finished_count==finishes:break
        if time.monotonic()>until:raise ValueError((p,expected,count,finishes,finished_count))
        time.sleep(2)
    uid="qaas-"+sl+"-usage-v1"
    data=api("GET","/api/datasources/uid/"+uid)
    data.update(database=alias)
    data["jsonData"]["index"]=alias
    api("PUT","/api/datasources/uid/"+uid,data)
    assert api("GET","/api/datasources/uid/"+uid+"/health")["status"]=="OK"
    filters={"all":{},"by_team":{"Team":"Payments"},"by_project":{"Project":"Ledger"},"by_system":{"System":"Orders"},"by_environment":{"Environment":"CI"},
             "by_mode":{"ExecutionType":"Assert" if p=="Runner" else "Run"},"by_version":{"Version":rows[0]["Version"]},
             "by_feature":{"Features":"Storage" if p=="Runner" else "https"},"all_dimensions":{"Team":"Payments","Project":"Ledger","System":"Billing","ExecutionType":"Run","Version":rows[0]["Version"],"Features":"Assertions" if p=="Runner" else "https","Environment":"CI"}}
    filters.update(empty={'Team':'nonexistent-lab-owner'},unknown={'Project':'(unattributed)'},past_grace={})
    for name,flt in filters.items():
        view={**window,'end':window['end']+20*60*1000} if name=='past_grace' else window
        with (folder/(p+"-"+name+"-query.log")).open("w",encoding="utf8") as log, redirect_stdout(log):
            frames=panel_frames(p,view,flt)
        (folder/(p+"-"+name+"-frames.json")).write_text(json.dumps(frames,indent=2),encoding="utf-8")
        result=oracle(p,events,view,flt,frames)
        assert not result["failures"],(p,name,result)
        out[p+"/"+name]=result
    print(p,len(rows),"original records",len(ids),"attempts",finishes,"terminals; verified",len(filters),"filter scenarios",flush=True)
(folder/"final-panels.json").write_text(json.dumps(out,indent=2))
