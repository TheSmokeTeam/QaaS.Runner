from pathlib import Path
from collections import Counter
import json, re,subprocess
from canonical import ROOT

here=Path(__file__).parent
scratch=here/"debug-compare"
scratch.mkdir(exist_ok=True)

def normalized(s):
    s=re.sub(r"^\[\d{2}:\d{2}:\d{2} ","[",s,flags=re.M)
    s=re.sub(r"Duration In Milliseconds: [\d.]+","Duration In Milliseconds: <duration>",s)
    s=re.sub(r"Session Utc (Start|End) Time: [^\n]+",r"Session Utc \1 Time: <time>",s)
    s=re.sub(r"(\\allure-results\\(?:SessionsData|SessionLogs|Templates)\\)\d{13}(?=\\)",r"\1<run-time>",s)
    s=re.sub(r"(\\allure-results\\)[a-f0-9]{32}(?=-attachment\.)",r"\1<attachment-id>",s)
    return [ln for ln in s.splitlines() if "RunnerExecutionStarted" not in ln and "RunnerExecutionFinished" not in ln]
res={}
for name,exitcode in [("good",0),("failed",1)]:
    streams={}
    for project in ["RunnerBase","Runner"]:
        host=ROOT/project/"QaaS.Runner.E2ETests/bin/Release/net10.0/QaaS.Runner.E2ETests.dll"
        cmd=["dotnet",str(host),"run",str(ROOT/"dashboard-validation"/(name+".yaml")),"--no-env","--disable-elastic-defaults","--logger-level","Debug"]
        log=subprocess.run(cmd,cwd=scratch,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        assert log.returncode==exitcode,(project,name,log.returncode)
        txt=log.stdout.decode("utf-8-sig",errors="replace").replace("\r\n","\n")
        (scratch/(project+"-"+name+".log")).write_text(txt,encoding="utf8")
        streams[project]=normalized(txt)
    base,head=streams["RunnerBase"],streams["Runner"]
    missing=Counter(base)-Counter(head)
    extra=Counter(head)-Counter(base)
    if missing or extra:
        (scratch/(name+"-delta.json")).write_text(json.dumps({"missing":dict(missing),"extra":dict(extra)},indent=2),encoding="utf8")
    assert not missing and not extra,(name,"See debug-compare delta",len(missing),len(extra))
    res["Runner "+name]={"exit":exitcode,"baseline_lines":len(base),"candidate_ordinary_lines":len(head),"identical_order":base==head}
live=here/(here/"current-live.txt").read_text().strip()
text="\n".join(f.read_text(encoding="utf8",errors="replace") for f in live.glob("qaas-revision-*.log"))
markers=["No HTTP action matched request","Falling back to stub","failed for request","Falling back to internal error stub","Application is shutting down","Runtime tasks completed"]
res["Mocker"]={m:m in text for m in markers}
res["Mocker"]["startup failure preserved"]="Unhandled exception" in (live/"mocker-failed.log").read_text(encoding="utf8",errors="replace")
assert all(res["Mocker"].values()),res["Mocker"]
(here/"debug-fidelity.json").write_text(json.dumps(res,indent=2))
print(json.dumps(res))
