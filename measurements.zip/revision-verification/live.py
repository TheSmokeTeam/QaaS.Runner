"""Run the local QaaS CLIs against one another. Only test-created containers are stopped."""
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from threading import Thread
import requests
from canonical import ROOT,req
HERE=Path(__file__).parent
R=ROOT/"Runner/QaaS.Runner.E2ETests/bin/Release/net10.0"
M=ROOT/"Mocker/QaaS.Mocker.Example/bin/Release/net10.0"
ES="http://127.0.0.1:19278"
def ms():return int(time.time()*1000)
def docker(*args):
    return subprocess.check_output(["docker",*map(str,args)],text=True,encoding="utf-8",errors="replace",timeout=90).strip()
def logrun(cmd,path,ci=False,expect=0):
    env=os.environ.copy()
    if ci:env["KUBERNETES_SERVICE_HOST"]="e2e-local"
    else:env.pop("KUBERNETES_SERVICE_HOST",None)
    with path.open("wb") as out:r=subprocess.run(cmd,cwd=path.parent,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=out,timeout=120)
    if not (r.returncode==expect if expect is not None else r.returncode!=0):raise ValueError((r.returncode,str(path),path.read_text(errors="replace")[-900:]))
    return r.returncode
def owner(team,system,project=None):
    return f'MetaData:\n  Team: {team}\n  System: {system}\n'+(f'  ExtraLabels:\n    Project: {project}\n' if project else '')
def fixture(folder,name,text):
    p=folder/name;p.write_text(text,encoding="utf-8");return p
def matches(since,until,product=None):
    query={"size":5000,"sort":[{"@timestamp":"asc"}],"_source":["@timestamp","fields"],"query":{"bool":{"filter":[
        {"exists":{"field":"fields.AttemptId"}},{"range":{"@timestamp":{"gte":since,"lte":until,"format":"epoch_millis"}}},
        {"terms":{"fields.Team.keyword":["Commerce","Payments"]}}]}}}
    hits=req("POST","/qaas-20*/_search",query)["hits"]["hits"]
    return [h["_source"] for h in hits if product is None or h["_source"]["fields"]["QaasEvent"].startswith(product)]
class Witness(BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_GET(self):
        conn=HTTPConnection("127.0.0.1",18145,timeout=10)
        try:
            conn.request("GET",self.path);r=conn.getresponse();data=r.read()
            self.server.receipts.append([self.path,r.status,data.decode()])
            self.send_response(r.status);self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data)
        finally:conn.close()
def run():
    folder=HERE/("live-"+uuid.uuid4().hex[:8]);folder.mkdir()
    (HERE/"current-live.txt").write_text(folder.name)
    files=[R/"QaaS.Runner.dll",R/"QaaS.Runner.E2ETests.dll",M/"QaaS.Mocker.dll",M/"QaaS.Mocker.Servers.dll",M/"QaaS.Mocker.Example.dll"]
    result={"from":ms()-100,"commands":[],"http":[],"quiet_batches":None,"runtime_sha256":{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
    def runner(name,args,ci=False,expected=0):
        cmd=["dotnet",str(R/"QaaS.Runner.E2ETests.dll"),*map(str,args),"--send-logs","--elastic-uri",ES]
        rc=logrun(cmd,folder/(name+".log"),ci,expected);result["commands"].append([name,rc])
    def server_config(team,system,project,port):
        old=(ROOT/"dashboard-validation/mocker.yaml").read_text(encoding="utf-8-sig")
        return owner(team,system,project)+"Stubs:"+old.split("Stubs:",1)[1].replace("18145",str(port))
    def serve(file,port):
        name="qaas-revision-"+uuid.uuid4().hex[:8];live.append(name)
        docker("run","--detach","--name",name,"--memory","250m","--cpus","1","--network","qaas-pr45-local",
               "-p",f"127.0.0.1:{port}:{port}","-v",str(M)+":/app-review:ro","-v",str(file)+":/fixture/mocker.yaml:ro",
               "--entrypoint","dotnet","mamtzetza-mocker","/app-review/QaaS.Mocker.Example.dll","run","/fixture/mocker.yaml",
               "--no-env","--send-logs","--elastic-uri","http://qaas-pr78-es:9200")
        until=time.monotonic()+75
        while time.monotonic()<until:
            if "Application started" in docker("logs",name):return name
            if docker("inspect","--format","{{.State.Running}}",name)!="true":break
            time.sleep(.4)
        raise RuntimeError(docker("logs",name)[-1200:])
    def stop(name,abrupt=False):
        if abrupt:docker("kill",name)
        else:docker("stop","--time","16",name)
        (folder/(name+".log")).write_text(docker("logs",name),encoding="utf-8")
        docker("rm",name);live.remove(name)
    def get(route,code):
        r=requests.get("http://127.0.0.1:18145/"+route,timeout=15)
        assert r.status_code==code,(route,r.status_code)
        result["http"].append([route,code])
    live=[]
    gw=ThreadingHTTPServer(("127.0.0.1",0),Witness);gw.receipts=[]
    th=Thread(target=gw.serve_forever,daemon=True);th.start()
    try:
        service=serve(fixture(folder,"mocker.yaml",server_config("Commerce","Orders","Storefront",18145)),18145)
        # Let an idle 10-second aggregation period elapse; this is an assertion, not warmup traffic.
        time.sleep(11)
        req("POST","/qaas-20*/_refresh")
        result["quiet_batches"]=sum(d["fields"]["QaasEvent"]=="MockerHttpRequests" for d in matches(result["from"],ms(),"Mocker"))
        assert result["quiet_batches"]==0
        get("ok",200);get("ok",200)
        base=(ROOT/"Runner/QaaS.Runner.Tests/TestData/http-get-empty-request.qaas.yaml").read_text()
        body="Sessions:"+base.split("Sessions:",1)[1].replace("TimeoutMs: 100","TimeoutMs: 5000").replace("Port: 1","Port: "+str(gw.server_port)).replace("Route: /","Route: /ok")
        ass="\nAssertions:\n  - Name: ObservedSuccess\n    Assertion: RabbitExhaustiveCombinationsAssertion\n    SessionNames: [empty-http-get]\n"
        good=fixture(folder,"checkout.yaml",owner("Commerce","Orders","Storefront")+body+ass)
        bad=fixture(folder,"billing.yaml",owner("Payments","Billing","Ledger")+body+ass+"  - Name: ExpectedFailure\n    Assertion: RabbitRoundTripAssertion\n    SessionNames: [empty-http-get]\n")
        runner("runner-good",["run",good,"--no-env"])
        runner("runner-fail",["run",bad,"--no-env"],True,1)
        assert gw.receipts==[["/ok",200,"healthy"]]*2,gw.receipts
        get("missing",404);get("missing",404)
        short=owner("Commerce","Orders")+"Storages:"+(ROOT/"bench/short.qaas.yaml").read_text().split("Storages:",1)[1]
        split=fixture(folder,"split.yaml",short)
        cases=folder/"cases";cases.mkdir()
        for c in ["North","South"]:fixture(cases,c+".yaml","MetaData:\n  System: Orders\n")
        seq=fixture(folder,"batch.yaml",f"Commands:\n  - Id: Prepare\n    Command: act {split.as_posix()} --no-env\n  - Id: Cases\n    Command: run {split.as_posix()} --no-env --cases {cases.as_posix()}\n")
        runner("runner-batch",["execute",seq],True)
        runner("runner-assert",["assert",split,"--no-env"])
        get("throw",500);get("degraded",503);get("ok",200);get("ok",200)
        stop(service)
        cert=folder/"invalid.pfx";cert.write_text("fixture invalid certificate")
        badserver=fixture(folder,"bad-server.yaml",server_config("Payments","Billing","Ledger",18145).replace("IsSecuredSchema: false",f"IsSecuredSchema: true\n      CertificatePath: {cert.as_posix()}\n      CertificatePassword: example"))
        cmd=["dotnet",str(M/"QaaS.Mocker.Example.dll"),"run",str(badserver),"--no-env","--send-logs","--elastic-uri",ES]
        rc=logrun(cmd,folder/"mocker-failed.log",True,None);result["commands"].append(["mocker-failed",rc])
        abrupt=serve(fixture(folder,"abrupt.yaml",server_config("Commerce","Catalog",None,18146)),18146)
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            req("POST","/qaas-20*/_refresh")
            if any(d["fields"]["System"]=="Catalog" for d in matches(result["from"],ms(),"Mocker")):break
            time.sleep(.3)
        else:raise RuntimeError("No live Mocker start indexed before SIGKILL")
        stop(abrupt,True)
    finally:
        gw.shutdown();gw.server_close()
        for name in list(live):
            try:stop(name,True)
            except Exception as e:print(e)
    result["to"]=ms()+100;result["witness"]=gw.receipts
    req("POST","/qaas-20*/_refresh")
    events=matches(result["from"],result["to"])
    (folder/"events.json").write_text(json.dumps(events,indent=2),encoding="utf-8")
    (folder/"receipt.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    for p in ["Runner","Mocker"]:
        rows=[e["fields"] for e in events if e["fields"]["QaasEvent"].startswith(p)]
        print(p,[(r["QaasEvent"],r["Team"],r["System"],r.get("Outcome"),r.get("AssertionsExecuted"),r.get("Requests"),r.get("Features")) for r in rows],flush=True)
    return folder
if __name__=="__main__":print(run())
