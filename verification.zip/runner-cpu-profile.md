# CPU profile of the five-plan Runner batch

The unprofiled healthy-sink benchmark measured a **21.2% wall-clock increase across nine paired CLI launches** (95% interval +13.6% to +29.5%). The requested 1–2% margin remains unverified for this workload. Six further process launches sampled the actual managed stacks and recorded Windows CPU counters to investigate the cause.

All six used the same Release `QaaS.Runner.dll`, SHA-256 `C3EB48295E4AB5678DAAB75313B49AEBABBC4EF730EAD6B4E22E049B3BA8DFE1`, from runtime source `1091914eba7a26062558e56df135379792a8f021`. Each started the real E2E CLI through its ordinary `execute` entry point with the same two-command YAML, one `act` configuration and one `run` configuration expanded into four named cases. Each exited zero. A transparent relay confirmed ten ordinary diagnostics in every launch. Each enabled launch also delivered five distinct starts and five distinct finishes to the same native Elasticsearch pipeline.

## Six profiled processes

Launch order was off/on, on/off and off/on. Windows process CPU is cumulative user plus kernel CPU across all target threads. The pre-entry column interpolates Windows process CPU snapshots at the first existing “Running Act execution” log. The two stack columns report elapsed weights of managed execution samples, in milliseconds. The sink column includes its client/batching descendants in the interval between the existing end-of-plans and final CLI diagnostics.

| Pair | Usage | Windows process CPU, ms | CPU before first plan, ms | Plan execution wall, ms | Direct usage stack weight, ms | Post-plan sink/client stack weight, ms | Accepted diagnostics / starts / finishes |
|---|---|---:|---:|---:|---:|---:|---|
| 1 | off | 2,359 | 2,078 | 124 | 0 | 50 | 10 / 0 / 0 |
| 1 | on | 2,453 | 2,141 | 102 | 2.0 | 50 | 10 / 5 / 5 |
| 2 | on | 3,281 | 2,580 | 272 | 1.9 | 21 | 10 / 5 / 5 |
| 2 | off | 6,781 | 5,235 | 1,149 | 0 | 199 | 10 / 0 / 0 |
| 3 | off | 6,156 | 5,594 | 144 | 0 | 89 | 10 / 0 / 0 |
| 3 | on | 3,953 | 3,547 | 110 | 2.0 | 94 | 10 / 5 / 5 |

The hottest repeated startup path was `ExecutionBuilderConfiguratorLoader.GetLoadableTypes` calling `Assembly.GetTypes` and `RuntimeModule.GetTypes`. It appears in both arms before the first plan reads `QAAS_USAGE_ENABLED`. Assembly loading/type enumeration accounted for roughly 410–1,532 ms of managed sample weight per process. Startup, Autofac resolution and unrelated scheduling varied substantially across launches. The busiest individual thread accounted for 73–89% of Windows process CPU. Two disabled runs had the highest CPU use.

All stacks containing `ExecutionUsage`, including synchronous logger descendants, totaled 1.9–2.0 ms in each enabled five-plan process. The sampled post-plan log/Elastic serialization weights were 4.0 versus 7.5 ms (pair 1, off/on), 3.5 versus 4.6 ms (pair 2), and 2.0 versus 10.1 ms (pair 3). Bulk flushing covered ordinary diagnostics in both arms. These traces do not isolate all native serializer, compression or remote service costs.

## Cross-check against independent timing

| Measurement | Off | On | Interpretation |
|---|---:|---:|---|
| Original nine-pair mean end-to-end wall | 2.094 s | 2.546 s | Confirms an operational regression on the tested host. |
| Original nine-pair mean child CPU | 2.014 s | 2.477 s | The difference includes local process work. |
| Mean bulk payload before compression | 4,707 bytes | 16,706 bytes | Ten additional structured usage documents per enabled launch. |
| Mean transmitted bulk body | 524 bytes | 1,441 bytes | One native bulk in every disabled and eight enabled launches. The other enabled launch sent two. |
| First real start/finish in a separate host probe | 0.35 ms | 1.93 ms | Cold lifecycle invocation includes the enabled logs and their enqueueing. |
| Warm real lifecycle invocation | 2.43 µs | 40.13 µs | The hook invokes the compiled start/finish methods against the existing logger. Async flushing takes place separately. |

An independent eight-pair, unprofiled phase run with the identical fixture measured mean wall deltas of **+413 ms before the first plan**, **−48 ms across all five plans**, **+120 ms from plans finished to CLI completion**, and **+7 ms from that final diagnostic to process exit**. On this run, mean process CPU deltas over those phases were +326, −62, +55 and +8 ms. The labels are established lifecycle diagnostics, so the third phase includes the regular publish/cleanup pipeline and logger disposal. It does not isolate Elasticsearch.

The source binds one parent logger to all five builders, executes the plans sequentially, and disposes the parent logger once during teardown. CPU sampling found no repeatable half-second hot path specific to the new measurements. The extra document bytes and the cost of logging are observable. The strongest consistent stack signal is shared pre-execution configurator discovery. A change to that loader would affect both arms and would require separate compatibility and performance tests. These observations do not establish a telemetry strategy change that recovers the measured end-to-end gap.

## Reproduction and limits

Use a Windows host with .NET 10, the specified Runner build, the benchmark’s fixed `phase-identical-batch.yaml` with its four case overrides, and a healthy local Elasticsearch relay. Keep the same fixture path and template settings for every arm. The profiler and all capture files were outside the repositories. The following abbreviated commands show the recorded providers and CLI arguments. Set `$runnerDll`, `$batchYaml`, `$relayUri`, `$traceFile` and `$side` for that launch.

```powershell
dotnet tool install dotnet-trace --tool-path ./.profile-tools --version 10.0.750501
$env:QAAS_USAGE_ENABLED = $side  # "true" or "false"
$env:DOTNET_DefaultDiagnosticPortSuspend = "1"
$child = Start-Process dotnet -ArgumentList @($runnerDll,'execute',$batchYaml,'--send-logs','--elastic-uri',$relayUri) -PassThru -NoNewWindow
Remove-Item Env:DOTNET_DefaultDiagnosticPortSuspend
./.profile-tools/dotnet-trace collect --process-id $child.Id --profile dotnet-sampled-thread-time,dotnet-common --buffersize 32 --duration 00:00:00:45 --output $traceFile
./.profile-tools/dotnet-trace convert $traceFile --format Speedscope
```

For the captured rows, a Python supervisor sampled Windows process and thread CPU counters approximately every 50 ms, timestamped unmodified CLI output with a monotonic clock, and waited for confirmed bulk receipts outside the measured run. Per-phase OS CPU is interpolated and coarser than a short plan or individual log. Stack labels come from the Windows EventPipe managed-thread sampler. The analysis accumulated only `CPU_TIME` stacks; `UNMANAGED_CODE_TIME` and sleeping stacks were excluded. The tables keep these managed sample weights separate from true OS CPU. Inclusive stack categories can overlap, and async work can outlive its initiating call. The sampled processes and instrumented timings are diagnostic evidence. The original unprofiled pairs determine the reported end-to-end budget result.
